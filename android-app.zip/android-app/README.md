# romnix - Android ROM Downloader & Transfer App

A modern Android application for downloading and transferring ROM files to handheld gaming devices. Built with Jetpack Compose and Material Design 3, this app provides a seamless experience for managing ROM collections across different gaming platforms.

## 🎮 Features

### Platform Management
- **Custom Platform Links**: Add and manage custom ROM sources from any archive.org URL
- **Dynamic Platform System**: No hardcoded platforms - fully user-configurable
- **Platform Validation**: Built-in validation for URL formats and file extensions
- **Easy Management**: Edit, delete, and organize platform links with intuitive UI

### ROM Discovery & Download
- **Smart Search**: Search across all platforms or filter by specific console
- **Archive.org Integration**: Seamless integration with Internet Archive for ROM discovery
- **Bulk Operations**: Download multiple ROMs simultaneously
- **Progress Tracking**: Real-time download progress with Android DownloadManager
- **File Organization**: Automatic organization by platform in dedicated folders

### Handheld Device Integration
- **Multiple Device Support**: Pre-configured templates for Rocknix and muOS devices
- **SSH Transfer**: Direct ROM transfer to handheld devices via SSH
- **Connection Management**: Persistent connection states with visual feedback
- **Manual Configuration**: Custom SSH settings for any compatible device
- **Bulk Transfer**: Transfer multiple ROMs to devices in one operation

### Modern UI/UX
- **Material Design 3**: Clean, modern interface following Google's design guidelines
- **Custom Typography**: Montserrat font throughout for professional appearance
- **Responsive Design**: Optimized for various Android screen sizes
- **Dark/Light Theme**: Consistent white theme with professional color scheme
- **Intuitive Navigation**: Tab-based navigation with custom icons

## 📱 Screenshots

The app features three main sections:
- **Home**: Platform management and custom link configuration
- **Search**: ROM discovery and download interface
- **Handhelds**: Device connection and transfer management

## 🛠 Technical Stack

### Architecture
- **Language**: Kotlin
- **UI Framework**: Jetpack Compose
- **Architecture Pattern**: MVVM with ViewModels
- **State Management**: Compose State and SharedPreferences
- **Navigation**: Custom tab-based navigation

### Key Dependencies
- **Jetpack Compose**: Modern Android UI toolkit
- **Material 3**: Google's latest design system
- **OkHttp**: HTTP client for network requests
- **SSHJ**: SSH client library for device transfers
- **Android DownloadManager**: System service for file downloads
- **Coroutines**: Asynchronous programming for smooth UX

### Core Components
- **PlatformManager**: Manages dynamic platform configuration
- **RomRepository**: Handles ROM discovery and HTML parsing
- **MainViewModel**: Central state management and business logic
- **SSH Transfer System**: Secure file transfer to handheld devices
- **Custom UI Components**: Reusable cards, dialogs, and navigation elements

## 🚀 Getting Started

### Prerequisites
- Android Studio (Giraffe or newer)
- Android SDK 24+ (Android 7.0)
- Kotlin support

### Installation
1. Clone the repository:
   ```bash
   git clone <repository-url>
   cd android-app
   ```

2. Open the project in Android Studio

3. Sync Gradle dependencies

4. Build and run the app:
   ```bash
   ./gradlew assembleDebug
   ```

### First Time Setup
1. **Add Platforms**: Start by adding custom platform links in the Home tab
2. **Configure Handhelds**: Set up your handheld device connections in the Handhelds tab
3. **Search ROMs**: Use the Search tab to discover and download ROMs
4. **Transfer Files**: Send downloaded ROMs directly to your handheld devices

## 🎯 Usage

### Adding Custom Platforms
1. Navigate to the **Home** tab
2. Tap the **+** button to add a new platform
3. Enter platform name, archive.org URL, and supported file extensions
4. Save to make the platform available for searching

### Downloading ROMs
1. Go to the **Search** tab
2. Select a platform or search across all platforms
3. Enter your search query and tap the search button
4. Browse results and tap download buttons to save ROMs locally
5. Use bulk download for multiple ROMs

### Transferring to Handhelds
1. Open the **Handhelds** tab
2. Choose a device template (Rocknix, muOS) or configure manually
3. Test the connection to ensure SSH access
4. Return to Search results and use transfer buttons to send ROMs directly to your device

## 🔧 Configuration

### SSH Connection Templates
The app includes pre-configured templates for popular handheld systems:

- **Rocknix**: Default settings for Rocknix-based devices
- **muOS**: Optimized configuration for muOS systems
- **Manual**: Custom configuration for any SSH-enabled device

### File Organization
Downloaded ROMs are organized as follows:
```
Android/data/com.example.romdownloader/files/Download/roms/
├── platform1/
│   ├── game1.rom
│   └── game2.rom
├── platform2/
│   ├── game3.rom
│   └── game4.rom
└── ...
```

## 🤝 Contributing

Contributions are welcome! Please feel free to submit issues, feature requests, or pull requests.

### Development Guidelines
- Follow Kotlin coding conventions
- Use Jetpack Compose for UI components
- Maintain Material Design 3 consistency
- Include appropriate error handling
- Test on multiple Android versions

## 📄 License

This project is open source. Please check the license file for specific terms.

## 🐛 Known Issues

- Network timeouts may occur with slow connections
- Some archive.org URLs may require specific formatting
- SSH transfers depend on device network configuration

## 📞 Support

For issues, questions, or feature requests, please create an issue in the project repository.

---

**ROM NIX** - Bringing retro gaming to modern handhelds with style and efficiency.

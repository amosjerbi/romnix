# ROM Downloader Web Application

A web-based version of the Android ROM downloader app, built with modern web technologies and Material Design 3 principles.

## Features

### 🎮 Gaming Platform Support
- **14 Gaming Platforms**: NES, SNES, Genesis, Game Boy, GBA, GBC, N64, PlayStation, Dreamcast, Saturn, Game Gear, Neo Geo Pocket, Sega Master System, TurboGrafx-16
- **Cross-Platform Compatibility**: Works on desktop, tablet, and mobile devices
- **Demo Mode**: Includes sample ROM data for testing when CORS restrictions prevent real data fetching

### 🔍 ROM Browsing & Search
- **Advanced Search**: Search across all platforms or filter by specific console
- **Quick Filters**: Fast access to popular platforms (Genesis, SNES, PS1, N64, GBA, NES)
- **Platform Selection**: Easy console selection with visual grid layout
- **Real-time Results**: Dynamic search results with loading animations

### 💾 Download Management
- **Individual Downloads**: Download single ROM files
- **Bulk Downloads**: Download multiple ROMs with progress tracking
- **Transfer Support**: Upload ROMs to SSH-enabled devices
- **Download & Transfer**: Combined download and transfer operations

### 🌐 Network & SSH Features
- **Host Discovery**: Scan local network for SSH-enabled devices
- **Manual Host Entry**: Add devices by IP address
- **SSH Configuration**: Configurable username, password, port, and remote paths
- **Connection Testing**: Test SSH connections before transfers
- **Template Support**: Pre-configured settings for popular handheld systems

### 📱 Handheld System Integration
- **Rocknix Support**: Pre-configured template for Rocknix devices
- **muOS Support**: Pre-configured template for muOS devices
- **Custom Configuration**: Manual SSH setup for other devices
- **Template Editor**: Modify and save custom connection templates

### 🎨 Modern UI/UX
- **Material Design 3**: Google's latest design system
- **Purple Theme**: Consistent color scheme matching the Android app
- **Responsive Design**: Optimized for all screen sizes
- **Dark Mode Ready**: Prepared for future dark theme support
- **Accessibility**: Keyboard navigation and screen reader support

## Getting Started

### Prerequisites
- Modern web browser (Chrome 90+, Firefox 88+, Safari 14+, Edge 90+)
- Python 3.x (for local development server)

### Running the Application

1. **Clone or Download** the project files
2. **Navigate** to the web-version directory:
   ```bash
   cd web-version
   ```
3. **Start a local server**:
   ```bash
   python3 -m http.server 8000
   ```
4. **Open your browser** and visit:
   ```
   http://localhost:8000
   ```

### Alternative Servers
You can also use other static file servers:

- **Node.js**:
  ```bash
  npx serve .
  ```
- **PHP**:
  ```bash
  php -S localhost:8000
  ```
- **Live Server** (VS Code extension)

## Usage Guide

### 1. Handheld Systems Tab
- Choose from pre-configured handheld systems (Rocknix, muOS)
- Click "Connect" to apply template settings
- Use "Edit Templates" to modify default configurations

### 2. Consoles Tab
- Browse available gaming platforms in a grid layout
- Use the search bar to filter consoles
- Click any console to browse its ROM library

### 3. ROM Browsing
- Search for specific games using the search bar
- Use platform filters to narrow results
- Use quick filter chips for popular platforms
- Download individual ROMs or use bulk download
- Transfer ROMs to connected SSH devices

### 4. Network Tab
- Scan your local network for SSH-enabled devices
- Manually add devices by IP address
- Configure SSH settings (username, password, port)
- Test connections before transferring files
- Set remote base paths for ROM storage

## Technical Details

### Architecture
- **Frontend**: Vanilla JavaScript ES6+, HTML5, CSS3
- **Styling**: Custom CSS with Material Design 3 principles
- **ROM Data**: Integrated with platforms.js repository system
- **Storage**: LocalStorage for templates and settings
- **Network**: Fetch API with CORS proxy support

### File Structure
```
web-version/
├── index.html          # Main application HTML
├── styles.css          # Complete styling with MD3 theme
├── app.js             # Main application logic
├── platforms.js       # ROM repository and platform definitions
└── README.md          # This file
```

### Browser Compatibility
- **Chrome**: 90+ ✅
- **Firefox**: 88+ ✅
- **Safari**: 14+ ✅
- **Edge**: 90+ ✅
- **Mobile**: iOS Safari 14+, Chrome Mobile 90+ ✅

### Performance Features
- **Lazy Loading**: Images and content loaded on demand
- **Debounced Search**: Optimized search input handling
- **Shimmer Loading**: Skeleton screens for better UX
- **Progressive Enhancement**: Core functionality works without JavaScript

## Demo Mode

Due to CORS (Cross-Origin Resource Sharing) restrictions, the application runs in demo mode by default, using sample ROM data. This allows you to test all features without needing a CORS proxy.

To use real ROM data, you would need:
1. A CORS proxy service
2. Backend server with appropriate CORS headers
3. Browser extension to disable CORS (development only)

## Customization

### Themes
The application uses CSS custom properties for easy theming:
```css
:root {
    --primary-color: #6B46C1;     /* Purple theme */
    --background-color: #FAFAFA;   /* Light background */
    --surface-color: #FFFFFF;      /* Card backgrounds */
    /* ... more variables ... */
}
```

### Adding New Platforms
Add new platforms to `platforms.js`:
```javascript
const platforms = {
    NEW_PLATFORM: {
        id: "new_platform",
        label: "New Platform",
        archiveUrl: "https://example.com/roms/",
        extensions: ["zip", "7z"],
        icon: "sports_esports"
    }
    // ... existing platforms
};
```

### Templates
Templates are stored in localStorage and can be modified through the UI or programmatically:
```javascript
const newTemplate = {
    name: "Custom Device",
    username: "user",
    password: "pass",
    port: "22",
    remoteBasePath: "/roms",
    hostIp: "192.168.1.100",
    useGuest: false,
    isDhcpNetwork: true
};
```

## Troubleshooting

### Common Issues

1. **Blank Page**: Check browser console for JavaScript errors
2. **No ROMs Found**: Demo mode is active, this is expected
3. **Search Not Working**: Ensure JavaScript is enabled
4. **Mobile Layout Issues**: Update to latest browser version
5. **SSH Features**: These simulate functionality in demo mode

### Development Tips

1. **Use Browser DevTools**: F12 for debugging
2. **Check Console**: Look for error messages
3. **Network Tab**: Monitor API requests
4. **Responsive Mode**: Test different screen sizes
5. **Lighthouse**: Audit performance and accessibility

## Future Enhancements

- **Dark Mode**: Complete dark theme implementation
- **PWA Support**: Progressive Web App with offline functionality
- **Real Backend**: Integration with actual ROM repositories
- **Advanced Filters**: More sophisticated filtering options
- **User Accounts**: Save preferences and favorites
- **Download Manager**: Enhanced download queue management

## Contributing

This is a demonstration project. For production use, consider:
- Adding proper error handling
- Implementing real authentication
- Adding comprehensive tests
- Setting up CI/CD pipeline
- Adding analytics and monitoring

## License

This project is for educational and demonstration purposes. Please respect copyright laws and only download ROMs you legally own.

---

**Note**: This web application replicates the functionality of the Android ROM downloader app while being fully responsive and accessible across all modern web browsers.

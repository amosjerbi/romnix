package com.example.romdownloader.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.romdownloader.MainViewModel
import com.example.romdownloader.Platform
import com.example.romdownloader.PlatformManager
import com.example.romdownloader.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    var showAddDialog by remember { mutableStateOf(false) }
    var refreshTrigger by remember { mutableStateOf(0) }
    
    // Force recomposition when platforms change
    LaunchedEffect(refreshTrigger) {
        PlatformManager.loadCustomPlatforms(context)
    }
    
    if (PlatformManager.all.isEmpty()) {
        // Home 1: Empty State (no gradient header)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.White)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // ROM NIX Logo (using the perfect light version from designs)
                Icon(
                    painter = painterResource(id = R.drawable.romnix_emptystate),
                    contentDescription = "ROM NIX Logo",
                    modifier = Modifier.size(140.dp),
                    tint = Color.Unspecified
                )
                
                Spacer(modifier = Modifier.height(32.dp))
                
                Text(
                    text = "NO PLATFORMS",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF111827),
                    fontSize = 20.sp,
                    letterSpacing = 0.5.sp
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Text(
                    text = "Add custom platform to get started",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF9CA3AF),
                    textAlign = TextAlign.Center,
                    fontSize = 14.sp
                )
                
                Spacer(modifier = Modifier.height(48.dp))
                
                // Perfect Circular Red FAB (no shadow, matching design exactly)
                FloatingActionButton(
                    onClick = { showAddDialog = true },
                    containerColor = Color(0xFFEF4444),
                    contentColor = Color.White,
                    modifier = Modifier.size(56.dp),
                    shape = CircleShape,
                    elevation = FloatingActionButtonDefaults.elevation(
                        defaultElevation = 0.dp,
                        pressedElevation = 0.dp,
                        focusedElevation = 0.dp,
                        hoveredElevation = 0.dp
                    )
                ) {
                    Icon(
                        Icons.Default.Add,
                        contentDescription = "Add Platform",
                        modifier = Modifier.size(24.dp),
                        tint = Color.White
                    )
                }
            }
        }
    } else {
        // Home 3: Filled State - Platform Links Management
        FilledHomeState(
            onAddPlatform = { showAddDialog = true },
            refreshTrigger = refreshTrigger,
            onRefresh = { refreshTrigger++ }
        )
    }
    
    // Home 2: Add Platform Modal
    if (showAddDialog) {
        AddPlatformModal(
            onDismiss = { showAddDialog = false },
            onSave = { platform ->
                PlatformManager.addCustomPlatform(context, platform)
                showAddDialog = false
                refreshTrigger++
            }
        )
    }
}

// Home 3: Filled State - Platform Links Management (no gradient header)
@Composable
private fun FilledHomeState(
    onAddPlatform: () -> Unit,
    refreshTrigger: Int,
    onRefresh: () -> Unit
) {
    val context = LocalContext.current
    var editingPlatform by remember { mutableStateOf<Platform?>(null) }
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Header with Add Button
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(top = 48.dp, bottom = 24.dp, start = 20.dp, end = 20.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Platform links",
                        style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF111827),
                        fontSize = 32.sp
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Text(
                        text = "Add custom platform to get started",
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF9CA3AF),
                        fontSize = 16.sp
                    )
                }
                
                // Red Add Button in Header
                FloatingActionButton(
                    onClick = onAddPlatform,
                    containerColor = Color(0xFFEF4444),
                    contentColor = Color.White,
                    modifier = Modifier.size(56.dp),
                    shape = CircleShape,
                    elevation = FloatingActionButtonDefaults.elevation(
                        defaultElevation = 0.dp,
                        pressedElevation = 0.dp,
                        focusedElevation = 0.dp,
                        hoveredElevation = 0.dp
                    )
                ) {
                    Icon(
                        Icons.Default.Add,
                        contentDescription = "Add Platform",
                        modifier = Modifier.size(24.dp),
                        tint = Color.White
                    )
                }
            }
            
            // Platform List
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(PlatformManager.all) { platform ->
                    PlatformLinkCard(
                        platform = platform,
                        onEdit = {
                            editingPlatform = platform
                        },
                        onDelete = {
                            PlatformManager.removeCustomPlatform(context, platform.id)
                            onRefresh()
                        }
                    )
                }
            }
        }
    }
    
    // Edit Platform Dialog
    if (editingPlatform != null) {
        EditPlatformDialog(
            platform = editingPlatform!!,
            onDismiss = { editingPlatform = null },
            onSave = { updatedPlatform ->
                PlatformManager.updateCustomPlatform(context, updatedPlatform)
                editingPlatform = null
                onRefresh()
            }
        )
    }
}

// Platform Link Card for Filled State
@Composable
private fun PlatformLinkCard(
    platform: Platform,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(1.dp, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFFF8F9FA)
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Platform name",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF9CA3AF),
                    fontSize = 12.sp
                )
                
                Spacer(modifier = Modifier.height(4.dp))
                
                Text(
                    text = platform.label,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF111827),
                    fontSize = 14.sp
                )
                
                Spacer(modifier = Modifier.height(4.dp))
                
                Text(
                    text = platform.archiveUrl,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF4AB5FB),
                    fontSize = 12.sp,
                    maxLines = 1
                )
            }
            
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(
                    onClick = onEdit,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.edit_18),
                        contentDescription = "Edit",
                        tint = Color(0xFF6B7280),
                        modifier = Modifier.size(16.dp)
                    )
                }
                
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.trash_18),
                        contentDescription = "Delete",
                        tint = Color(0xFF6B7280),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

// Home 2: Add Platform Modal (exact design match)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddPlatformModal(
    onDismiss: () -> Unit,
    onSave: (Platform) -> Unit
) {
    var platformName by remember { mutableStateOf("") }
    var archiveUrl by remember { mutableStateOf("") }
    var extensions by remember { mutableStateOf("gbc, 7z") }
    var showNameError by remember { mutableStateOf(false) }
    var showUrlError by remember { mutableStateOf(false) }
    
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = Color.White
            )
        ) {
            Column(
                modifier = Modifier.padding(24.dp)
            ) {
                Text(
                    text = "ADD A PLATFORM",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF111827),
                    fontSize = 18.sp,
                    letterSpacing = 1.sp
                )
                
                Spacer(modifier = Modifier.height(24.dp))
                
                // Platform Name Field
                OutlinedTextField(
                    value = platformName,
                    onValueChange = { 
                        platformName = it
                        showNameError = false
                    },
                    placeholder = { 
                        Text(
                            "Platform name",
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFFD1D5DB)
                        ) 
                    },
                    modifier = Modifier.fillMaxWidth(),
                    isError = showNameError,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF6366F1),
                        unfocusedBorderColor = Color(0xFFE5E7EB),
                        focusedTextColor = Color(0xFF111827),
                        unfocusedTextColor = Color(0xFF111827),
                        cursorColor = Color(0xFF6366F1)
                    ),
                    shape = RoundedCornerShape(8.dp)
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Archive URL Field
                OutlinedTextField(
                    value = archiveUrl,
                    onValueChange = { 
                        archiveUrl = it
                        showUrlError = false
                    },
                    placeholder = { 
                        Text(
                            "Archive URL",
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFFD1D5DB)
                        ) 
                    },
                    modifier = Modifier.fillMaxWidth(),
                    isError = showUrlError,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF6366F1),
                        unfocusedBorderColor = Color(0xFFE5E7EB),
                        focusedTextColor = Color(0xFF111827),
                        unfocusedTextColor = Color(0xFF111827),
                        cursorColor = Color(0xFF6366F1)
                    ),
                    shape = RoundedCornerShape(8.dp)
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // File Extensions Field
                OutlinedTextField(
                    value = extensions,
                    onValueChange = { extensions = it },
                    placeholder = { 
                        Text(
                            "File extensions",
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFFD1D5DB)
                        ) 
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF6366F1),
                        unfocusedBorderColor = Color(0xFFE5E7EB),
                        focusedTextColor = Color(0xFF111827),
                        unfocusedTextColor = Color(0xFF111827),
                        cursorColor = Color(0xFF6366F1)
                    ),
                    shape = RoundedCornerShape(8.dp),
                    supportingText = {
                        Text(
                            "Comma-separated list of file",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF9CA3AF),
                            fontSize = 12.sp
                        )
                    }
                )
                
                Spacer(modifier = Modifier.height(32.dp))
                
                // Save Button (Red)
                Button(
                    onClick = {
                        val trimmedName = platformName.trim()
                        val trimmedUrl = archiveUrl.trim()
                        
                        showNameError = trimmedName.isEmpty()
                        showUrlError = trimmedUrl.isEmpty() || !trimmedUrl.startsWith("http")
                        
                        if (!showNameError && !showUrlError) {
                            val extensionsList = extensions.split(",").map { it.trim() }.filter { it.isNotEmpty() }
                            val id = trimmedName.lowercase().replace(" ", "")
                            
                            onSave(
                                Platform(
                                    id = id,
                                    label = trimmedName,
                                    archiveUrl = trimmedUrl,
                                    extensions = extensionsList.ifEmpty { listOf("7z", "zip") },
                                    isCustom = true
                                )
                            )
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFEF4444)
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        "SAVE",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        letterSpacing = 1.sp
                    )
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Cancel Button
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        "CANCEL",
                        color = Color(0xFF6B7280),
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        letterSpacing = 1.sp
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EditPlatformDialog(
    platform: Platform,
    onDismiss: () -> Unit,
    onSave: (Platform) -> Unit
) {
    var platformName by remember { mutableStateOf(platform.label) }
    var archiveUrl by remember { mutableStateOf(platform.archiveUrl) }
    var extensions by remember { mutableStateOf(platform.extensions.joinToString(", ")) }
    
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(
                modifier = Modifier.padding(24.dp)
            ) {
                Text(
                    text = "EDIT PLATFORM",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF111827),
                    fontSize = 18.sp
                )
                
                Spacer(modifier = Modifier.height(24.dp))
                
                OutlinedTextField(
                    value = platformName,
                    onValueChange = { platformName = it },
                    label = { Text("Platform name") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color(0xFF111827),
                        unfocusedTextColor = Color(0xFF111827),
                        cursorColor = Color(0xFF6366F1)
                    ),
                    shape = RoundedCornerShape(8.dp)
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                OutlinedTextField(
                    value = archiveUrl,
                    onValueChange = { archiveUrl = it },
                    label = { Text("Archive URL") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color(0xFF111827),
                        unfocusedTextColor = Color(0xFF111827),
                        cursorColor = Color(0xFF6366F1)
                    ),
                    shape = RoundedCornerShape(8.dp)
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                OutlinedTextField(
                    value = extensions,
                    onValueChange = { extensions = it },
                    label = { Text("File extensions") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color(0xFF111827),
                        unfocusedTextColor = Color(0xFF111827),
                        cursorColor = Color(0xFF6366F1)
                    ),
                    shape = RoundedCornerShape(8.dp)
                )
                
                Spacer(modifier = Modifier.height(24.dp))
                
                Button(
                    onClick = {
                        if (platformName.isNotBlank() && archiveUrl.isNotBlank()) {
                            val extensionsList = extensions.split(",").map { it.trim() }
                            onSave(
                                platform.copy(
                                    label = platformName,
                                    archiveUrl = archiveUrl,
                                    extensions = extensionsList
                                )
                            )
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444))
                ) {
                    Text("SAVE", color = Color.White, fontWeight = FontWeight.Bold)
                }
                
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("CANCEL", color = Color(0xFF6B7280), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

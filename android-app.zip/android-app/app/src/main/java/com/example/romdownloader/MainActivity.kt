package com.example.romdownloader

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.shadow
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.AlertDialog
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Games
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.VideogameAsset
import androidx.compose.material.icons.filled.SearchOff
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.draw.clip
import com.example.romdownloader.ui.screens.HandheldScreen
import com.example.romdownloader.ui.screens.BrowseScreen
import com.example.romdownloader.ui.screens.ConsoleSelectScreen
import com.example.romdownloader.ui.screens.SettingsScreen
import com.example.romdownloader.ui.screens.HomeScreen
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import android.util.Log
import com.example.romdownloader.network.HostConfig
import com.example.romdownloader.ui.theme.AppTheme
import com.example.romdownloader.network.HostScanner
import com.example.romdownloader.network.SshUploader
import com.example.romdownloader.network.SshTester
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.net.URLDecoder
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Light system bars on white backgrounds: show dark (black) icons
        window.statusBarColor = android.graphics.Color.WHITE
        window.navigationBarColor = android.graphics.Color.WHITE
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            // Ensure decorView is attached before accessing insetsController
            window.decorView.post {
                window.insetsController?.setSystemBarsAppearance(
                    android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
                        android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS,
                    android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
                        android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
                )
            }
        } else {
            @Suppress("DEPRECATION")
            run {
                var flags = android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    flags = flags or android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
                }
                window.decorView.post { window.decorView.systemUiVisibility = flags }
            }
        }
        
        setContent {
            AppTheme {
                RomApp(viewModel = viewModel, downloader = AndroidDownloader(this))
            }
        }
    }
}

data class Platform(
    val id: String, 
    val label: String, 
    val archiveUrl: String, 
    val extensions: List<String>,
    val isCustom: Boolean = false
)

object PlatformManager {
    private val defaultPlatforms = emptyList<Platform>()
    
    private var customPlatforms = mutableListOf<Platform>()
    
    val all: List<Platform>
        get() = defaultPlatforms + customPlatforms
    
    fun loadCustomPlatforms(context: Context) {
        val sp = context.getSharedPreferences("custom_platforms", Context.MODE_PRIVATE)
        val platformsJson = sp.getString("platforms", "[]")
        try {
            customPlatforms.clear()
            // Simple JSON parsing for custom platforms
            if (platformsJson != "[]") {
                val platformsData = parseCustomPlatformsJson(platformsJson!!)
                customPlatforms.addAll(platformsData)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
    
    fun saveCustomPlatforms(context: Context) {
        val sp = context.getSharedPreferences("custom_platforms", Context.MODE_PRIVATE)
        val json = customPlatformsToJson(customPlatforms)
        sp.edit().putString("platforms", json).apply()
    }
    
    fun addCustomPlatform(context: Context, platform: Platform) {
        val customPlatform = platform.copy(isCustom = true)
        customPlatforms.removeAll { it.id == customPlatform.id }
        customPlatforms.add(customPlatform)
        saveCustomPlatforms(context)
    }
    
    fun removeCustomPlatform(context: Context, platformId: String) {
        customPlatforms.removeAll { it.id == platformId }
        saveCustomPlatforms(context)
    }
    
    fun updateCustomPlatform(context: Context, platform: Platform) {
        val index = customPlatforms.indexOfFirst { it.id == platform.id }
        if (index != -1) {
            customPlatforms[index] = platform.copy(isCustom = true)
            saveCustomPlatforms(context)
        }
    }
    
    private fun parseCustomPlatformsJson(json: String): List<Platform> {
        val platforms = mutableListOf<Platform>()
        try {
            // Simple manual JSON parsing
            val cleanJson = json.trim().removePrefix("[").removeSuffix("]")
            if (cleanJson.isNotEmpty()) {
                val platformObjects = cleanJson.split("},{").map { 
                    if (!it.startsWith("{")) "{$it" else it
                }.map { 
                    if (!it.endsWith("}")) "$it}" else it
                }
                
                for (obj in platformObjects) {
                    val platform = parsePlatformObject(obj)
                    if (platform != null) platforms.add(platform)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return platforms
    }
    
    private fun parsePlatformObject(obj: String): Platform? {
        try {
            val fields = mutableMapOf<String, String>()
            val content = obj.trim().removePrefix("{").removeSuffix("}")
            val parts = content.split("\",\"")
            
            for (part in parts) {
                val keyValue = part.split("\":\"", limit = 2)
                if (keyValue.size == 2) {
                    val key = keyValue[0].trim().removePrefix("\"").removeSuffix("\"")
                    val value = keyValue[1].trim().removePrefix("\"").removeSuffix("\"")
                    fields[key] = value
                }
            }
            
            val id = fields["id"] ?: return null
            val label = fields["label"] ?: return null
            val archiveUrl = fields["archiveUrl"] ?: return null
            val extensionsStr = fields["extensions"] ?: "7z,zip"
            val extensions = extensionsStr.split(",").map { it.trim() }
            
            return Platform(id, label, archiveUrl, extensions, true)
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }
    
    private fun customPlatformsToJson(platforms: List<Platform>): String {
        if (platforms.isEmpty()) return "[]"
        
        val platformStrings = platforms.map { platform ->
            "{\"id\":\"${platform.id}\",\"label\":\"${platform.label}\",\"archiveUrl\":\"${platform.archiveUrl}\",\"extensions\":\"${platform.extensions.joinToString(",")}\"}"
        }
        return "[${platformStrings.joinToString(",")}]"
    }
}

data class RomItem(val displayName: String, val downloadUrl: String, val platform: Platform)

data class DiscoveredHost(val ip: String)

interface Downloader { fun download(context: Context, item: RomItem) }

data class HostTemplate(
    val name: String,
    val username: String,
    val password: String,
    val port: String,
    val remoteBasePath: String,
    val hostIp: String,
    val useGuest: Boolean,
    val isDhcpNetwork: Boolean
)

class AndroidDownloader(private val context: Context) : Downloader {
    override fun download(context: Context, item: RomItem) {
        val request = DownloadManager.Request(Uri.parse(item.downloadUrl))
            .setTitle(item.displayName)
            .setDescription("Downloading to ${item.platform.label}")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalFilesDir(
                context,
                Environment.DIRECTORY_DOWNLOADS,
                "roms/${item.platform.id}/${item.displayName}"
            )
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(true)
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        dm.enqueue(request)
    }
}

class RomRepository(private val client: OkHttpClient = OkHttpClient.Builder()
    .connectTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
    .readTimeout(60, java.util.concurrent.TimeUnit.SECONDS)
    .writeTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
    .followRedirects(true)
    .followSslRedirects(true)
    .addInterceptor { chain ->
        val request = chain.request()
        val response = chain.proceed(request)
        android.util.Log.d("RomSearch", "Interceptor - Response headers: ${response.headers}")
        response
    }
    .build()) {
    // Match <a ... href="..." ...>
    private val linkRegex = Regex("<a\\s+[^>]*href=\\\"([^\\\"]+)\\\"", RegexOption.IGNORE_CASE)

    private fun fetchHtml(url: String): String {
        android.util.Log.d("RomSearch", "Fetching HTML from: $url")
        val request = Request.Builder()
            .url(url)
            .header(
                "User-Agent",
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
            )
            .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8")
            .header("Accept-Language", "en-US,en;q=0.9")
            .header("DNT", "1")
            .header("Connection", "keep-alive")
            .header("Upgrade-Insecure-Requests", "1")
            .get()
            .build()
        return client.newCall(request).execute().use { response ->
            android.util.Log.d("RomSearch", "HTTP Response: ${response.code} ${response.message}")
            android.util.Log.d("RomSearch", "Final URL after redirects: ${response.request.url}")
            
            if (!response.isSuccessful) {
                android.util.Log.e("RomSearch", "HTTP request failed: ${response.code} ${response.message}")
                return@use ""
            }
            
            val responseBody = response.body
            if (responseBody == null) {
                android.util.Log.e("RomSearch", "Response body is null")
                return@use ""
            }
            
            // Check content encoding
            val contentEncoding = response.header("Content-Encoding")
            android.util.Log.d("RomSearch", "Content-Encoding: $contentEncoding")
            
            val html = try {
                responseBody.string()
            } catch (e: Exception) {
                android.util.Log.e("RomSearch", "Error reading response body: ${e.message}")
                ""
            }
            
            android.util.Log.d("RomSearch", "HTML length: ${html.length}")
            
            if (html.length > 0) {
                // Check if content looks like binary/compressed data
                val hasNullBytes = html.contains('\u0000')
                val hasControlChars = html.take(100).count { it.code < 32 && it != '\n' && it != '\r' && it != '\t' } > 5
                
                if (hasNullBytes || hasControlChars) {
                    android.util.Log.w("RomSearch", "⚠ HTML appears to be binary/compressed data")
                    android.util.Log.d("RomSearch", "First 50 bytes as hex: ${html.take(50).map { "%02x".format(it.code.toByte()) }.joinToString(" ")}")
                } else {
                    android.util.Log.d("RomSearch", "HTML preview: ${html.take(200)}...")
                    // Check if we got the right page
                    if (html.contains("GameBoyColor") || html.contains(".gbc") || html.contains("10-pin bowling")) {
                        android.util.Log.d("RomSearch", "✓ Found GameBoy Color content")
                    } else {
                        android.util.Log.w("RomSearch", "⚠ HTML doesn't contain GameBoy Color content - might be wrong page")
                    }
                }
            }
            html
        }
    }

    private fun buildAbsoluteUrl(base: String, href: String): String {
        val normalizedBase = base.trimEnd('/') + "/"
        return if (href.startsWith("http://") || href.startsWith("https://")) href else normalizedBase + href.trimStart('/')
    }

    private fun isDirectoryLink(href: String): Boolean {
        if (href.isBlank()) return false
        if (href.startsWith("?")) return false
        if (href == "/") return false
        if (href.startsWith("../")) return false
        return href.endsWith("/")
    }

    private fun parseDirectoryRecursively(baseUrl: String, exts: Set<String>, depth: Int): List<RomItem> {
        android.util.Log.d("RomSearch", "Parsing directory: $baseUrl (depth: $depth)")
        val results = mutableListOf<RomItem>()
        
        try {
        val html = fetchHtml(baseUrl)
            if (html.isEmpty()) {
                android.util.Log.w("RomSearch", "Empty HTML response for: $baseUrl")
                return results
            }
            
        val links = linkRegex.findAll(html).mapNotNull { it.groupValues.getOrNull(1) }.toList()
            android.util.Log.d("RomSearch", "Found ${links.size} links in $baseUrl")
            
            var processedLinks = 0
        for (href in links) {
                processedLinks++
                if (processedLinks % 50 == 0) {
                    android.util.Log.d("RomSearch", "Processed $processedLinks/${links.size} links...")
                }
                
            val decoded = try { URLDecoder.decode(href, "UTF-8") } catch (e: Exception) { href }
            val lower = decoded.lowercase(Locale.ROOT)
                
                // Debug: Log first few files to see what we're getting
                if (results.isEmpty() && !isDirectoryLink(href) && processedLinks <= 3) {
                    android.util.Log.d("RomSearch", "Sample file: '$decoded' (lowercase: '$lower')")
                    android.util.Log.d("RomSearch", "Extensions looking for: $exts")
                    android.util.Log.d("RomSearch", "Checking if ends with: ${exts.map { ".$it" }}")
                }
                
            if (isDirectoryLink(href)) {
                if (depth > 0) {
                        android.util.Log.d("RomSearch", "Following subdirectory: $href")
                    val nextUrl = buildAbsoluteUrl(baseUrl, href)
                        try {
                    results += parseDirectoryRecursively(nextUrl, exts, depth - 1)
                        } catch (e: Exception) {
                            android.util.Log.e("RomSearch", "Error parsing subdirectory $nextUrl: ${e.message}")
                        }
                }
                continue
            }
                
            if (exts.any { lower.endsWith(".$it") }) {
                val nameOnly = decoded.substringAfterLast('/')
                val fullUrl = buildAbsoluteUrl(baseUrl, href)
                    android.util.Log.d("RomSearch", "Found ROM: $nameOnly")
                    results += RomItem(displayName = nameOnly, downloadUrl = fullUrl, platform = PlatformManager.all.firstOrNull() ?: Platform("unknown", "Unknown", "", listOf()))
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("RomSearch", "Error parsing directory $baseUrl: ${e.message}")
            e.printStackTrace()
        }
        
        android.util.Log.d("RomSearch", "Total ROMs found for $baseUrl: ${results.size}")
        return results
    }

    suspend fun search(platform: Platform, term: String): List<RomItem> = withContext(Dispatchers.IO) {
        val startUrl = platform.archiveUrl.trimEnd('/') + "/"
        val exts = platform.extensions.map { it.lowercase(Locale.ROOT).removePrefix(".") }.toSet()
        
        android.util.Log.d("RomSearch", "Starting search for platform: ${platform.label}")
        android.util.Log.d("RomSearch", "URL: $startUrl")
        android.util.Log.d("RomSearch", "Extensions: $exts")
        android.util.Log.d("RomSearch", "Search term: '$term'")
        
        try {
            // Use withTimeout to prevent hanging
            val rawItems = withTimeout(120_000) { // 2 minute timeout
                parseDirectoryRecursively(startUrl, exts, depth = 1) // Reduced depth to prevent infinite loops
            }
        val items = rawItems.map { it.copy(platform = platform) }
            val filteredItems = if (term.isBlank()) items else items.filter { it.displayName.contains(term, ignoreCase = true) }
            
            android.util.Log.d("RomSearch", "Final results: ${filteredItems.size} items")
            return@withContext filteredItems
        } catch (e: kotlinx.coroutines.TimeoutCancellationException) {
            android.util.Log.e("RomSearch", "Search timed out after 2 minutes")
            return@withContext emptyList()
        } catch (e: Exception) {
            android.util.Log.e("RomSearch", "Search failed: ${e.message}")
            e.printStackTrace()
            return@withContext emptyList()
        }
    }
}

class MainViewModel : ViewModel() {
    var selectedPlatform by mutableStateOf<Platform?>(null)
        private set
    var searchTerm by mutableStateOf("")
        private set
    var results by mutableStateOf<List<RomItem>>(emptyList())
        private set
    var isSearching by mutableStateOf(false)
        private set

    var hosts by mutableStateOf<List<DiscoveredHost>>(emptyList())
        private set
    var selectedHost by mutableStateOf<DiscoveredHost?>(null)
        private set
    var isScanning by mutableStateOf(false)
        private set

    private val repo = RomRepository()
    private val scanner = HostScanner()
    private val uploader = SshUploader()
    private val tester = SshTester()

    fun setPlatform(p: Platform?) { selectedPlatform = p }
    fun updateSearchTerm(t: String) { searchTerm = t }
    
    fun clearResults() { results = emptyList() }

    fun searchAll() {
        val term = searchTerm
        isSearching = true
        results = emptyList()
        viewModelScope.launch {
            val aggregated = mutableListOf<RomItem>()
            for (p in PlatformManager.all) {
                val list = runCatching { repo.search(p, term) }.getOrDefault(emptyList())
                aggregated += list
            }
            results = aggregated
            isSearching = false
        }
    }

    fun searchSelected() {
        val term = searchTerm
        val p = selectedPlatform ?: return
        isSearching = true
        results = emptyList()
        viewModelScope.launch {
            val list = runCatching { repo.search(p, term) }.getOrDefault(emptyList())
            results = list
            isSearching = false
        }
    }

    fun scanHosts() {
        isScanning = true
        hosts = emptyList()
        selectedHost = null
        viewModelScope.launch(Dispatchers.IO) {
            val prefix = scanner.getLocalSubnetPrefix()
            val found = if (prefix != null) scanner.scanQuick(prefix) else emptyList()
            withContext(Dispatchers.Main) {
                hosts = found.map { DiscoveredHost(it) }
                selectedHost = hosts.firstOrNull()
                isScanning = false
            }
        }
    }

    fun selectHost(h: DiscoveredHost?) { 
        selectedHost = h
        // Try to determine template based on IP
        if (h != null) {
            val detectedTemplate = when (h.ip) {
                rocknixTemplate.hostIp -> "Rocknix"
                muosTemplate.hostIp -> "muOS"
                else -> connectedTemplate // Keep current template if no match
            }
            updateConnectedTemplate(detectedTemplate)
            android.util.Log.d("RomTransfer", "Host selected: ${h.ip}, detected template: $connectedTemplate")
        }
    }

    fun addHostFromIp(ip: String): Boolean {
        val trimmed = ip.trim()
        val ipv4 = Regex("^((25[0-5]|2[0-4]\\d|[0-1]?\\d{1,2})\\.){3}(25[0-5]|2[0-4]\\d|[0-1]?\\d{1,2})$")
        if (!ipv4.matches(trimmed)) return false
        val host = DiscoveredHost(trimmed)
        if (hosts.none { it.ip == host.ip }) {
            hosts = hosts + host
        }
        selectedHost = host
        return true
    }

    // Connection settings
    var sshUsername by mutableStateOf("root")
    var sshPassword by mutableStateOf("root")
    var sshPort by mutableStateOf("22")
    var useGuest by mutableStateOf(false)
    var isDhcpNetwork by mutableStateOf(true)
    var remoteBasePath by mutableStateOf("")
    
    // Track which template was used for connection (persistent)
    var connectedTemplate by mutableStateOf<String?>(null)
        private set

    // Templates state
    var rocknixTemplate by mutableStateOf(
        HostTemplate(
            name = "Rocknix",
            username = "root",
            password = "rocknix",
            port = "22",
            remoteBasePath = "/storage/roms",
            hostIp = "192.168.0.132",
            useGuest = false,
            isDhcpNetwork = true
        )
    )
    var muosTemplate by mutableStateOf(
        HostTemplate(
            name = "muOS",
            username = "root",
            password = "muos",
            port = "22",
            remoteBasePath = "/mnt/mmc/ROMS",
            hostIp = "192.168.1.101",
            useGuest = false,
            isDhcpNetwork = true
        )
    )

    private fun templateKey(name: String, field: String): String = "template.${name}.${field}"

    private fun getStringPref(sp: android.content.SharedPreferences, key: String, default: String): String {
        val anyValue = sp.all[key]
        return when (anyValue) {
            is String -> anyValue
            else -> default
        }
    }

    fun loadTemplates(context: Context) {
        val sp = context.getSharedPreferences("templates", Context.MODE_PRIVATE)
        fun readDefaulting(base: HostTemplate): HostTemplate {
            val n = base.name
            return HostTemplate(
                name = n,
                username = getStringPref(sp, templateKey(n, "username"), base.username),
                password = getStringPref(sp, templateKey(n, "password"), base.password),
                port = getStringPref(sp, templateKey(n, "port"), base.port),
                remoteBasePath = getStringPref(sp, templateKey(n, "remoteBasePath"), base.remoteBasePath),
                hostIp = getStringPref(sp, templateKey(n, "hostIp"), base.hostIp),
                useGuest = sp.getBoolean(templateKey(n, "useGuest"), base.useGuest),
                isDhcpNetwork = sp.getBoolean(templateKey(n, "isDhcpNetwork"), base.isDhcpNetwork)
            )
        }
        rocknixTemplate = readDefaulting(rocknixTemplate)
        muosTemplate = readDefaulting(muosTemplate)
        
        // Load manual SSH settings
        sshUsername = getStringPref(sp, "manual_username", "root")
        sshPassword = getStringPref(sp, "manual_password", "root")
        sshPort = getStringPref(sp, "manual_port", "22")
        remoteBasePath = getStringPref(sp, "manual_remotePath", "/storage/roms")
        useGuest = sp.getBoolean("manual_useGuest", false)
        isDhcpNetwork = sp.getBoolean("manual_isDhcpNetwork", true)
        
        // Load connected template state
        connectedTemplate = sp.getString("connected_template", null)
    }

    fun updateTemplate(context: Context, updated: HostTemplate) {
        when (updated.name) {
            "Rocknix" -> rocknixTemplate = updated
            "muOS" -> muosTemplate = updated
        }
        val sp = context.getSharedPreferences("templates", Context.MODE_PRIVATE)
        val n = updated.name
        sp.edit()
            .putString(templateKey(n, "username"), updated.username)
            .putString(templateKey(n, "password"), updated.password)
            .putString(templateKey(n, "port"), updated.port)
            .putString(templateKey(n, "remoteBasePath"), updated.remoteBasePath)
            .putString(templateKey(n, "hostIp"), updated.hostIp)
            .putBoolean(templateKey(n, "useGuest"), updated.useGuest)
            .putBoolean(templateKey(n, "isDhcpNetwork"), updated.isDhcpNetwork)
            .apply()
    }
    
    fun saveManualSettings(context: Context) {
        val sp = context.getSharedPreferences("templates", Context.MODE_PRIVATE)
        sp.edit()
            .putString("manual_username", sshUsername)
            .putString("manual_password", sshPassword)
            .putString("manual_port", sshPort)
            .putString("manual_remotePath", remoteBasePath)
            .putBoolean("manual_useGuest", useGuest)
            .putBoolean("manual_isDhcpNetwork", isDhcpNetwork)
            .putString("connected_template", connectedTemplate)
            .apply()
    }
    
    fun updateConnectedTemplate(template: String?) {
        connectedTemplate = template
        // Save immediately to persist across tab switches
        android.util.Log.d("RomTransfer", "Connected template changed to: $template")
    }

    fun getTemplate(name: String): HostTemplate = when (name) {
        "Rocknix" -> rocknixTemplate
        "muOS" -> muosTemplate
        else -> rocknixTemplate
    }

    fun applyTemplateRocknix(context: Context) {
        val t = rocknixTemplate
        sshUsername = t.username
        sshPassword = t.password
        sshPort = t.port
        useGuest = t.useGuest
        isDhcpNetwork = t.isDhcpNetwork
        remoteBasePath = t.remoteBasePath
        updateConnectedTemplate("Rocknix")
        saveManualSettings(context) // Save state immediately
        if (t.hostIp.isNotBlank()) addHostFromIp(t.hostIp)
    }

    fun applyTemplateMuOS(context: Context) {
        val t = muosTemplate
        sshUsername = t.username
        sshPassword = t.password
        sshPort = t.port
        useGuest = t.useGuest
        isDhcpNetwork = t.isDhcpNetwork
        remoteBasePath = t.remoteBasePath
        updateConnectedTemplate("muOS")
        saveManualSettings(context) // Save state immediately
        if (t.hostIp.isNotBlank()) addHostFromIp(t.hostIp)
    }
    
    fun initializePlatforms(context: Context) {
        PlatformManager.loadCustomPlatforms(context)
        if (selectedPlatform == null && PlatformManager.all.isNotEmpty()) {
            selectedPlatform = PlatformManager.all.firstOrNull()
        }
    }
    
    fun testConnection(
        hostIp: String,
        username: String,
        password: String,
        port: Int,
        onResult: (Boolean) -> Unit
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val hostConfig = com.example.romdownloader.network.HostConfig(
                    host = hostIp,
                    port = port,
                    username = username,
                    password = password
                )
                val result = tester.test(hostConfig)
                withContext(Dispatchers.Main) {
                    onResult(result.isSuccess)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    onResult(false)
                }
            }
        }
    }

    fun uploadFile(localFile: File, platform: Platform, onResult: (Boolean, String?) -> Unit) {
        val hostIp = selectedHost?.ip ?: return onResult(false, "No host selected")
        viewModelScope.launch(Dispatchers.IO) {
            val port = sshPort.toIntOrNull() ?: 22
            val username = if (useGuest) sshUsername.ifEmpty { "root" } else sshUsername.ifEmpty { "root" }
            val password = if (useGuest) "" else sshPassword
            val res = uploader.upload(localFile, platform.id, HostConfig(host = hostIp, port = port, username = username, password = password), baseOverride = remoteBasePath)
            val msg = res.exceptionOrNull()?.message ?: res.getOrNull() ?: ""
            Log.d("RomDL", "Upload result isSuccess=${res.isSuccess} pathOrError=${msg}")
            withContext(Dispatchers.Main) { onResult(res.isSuccess, msg) }
        }
    }

    fun downloadAndTransfer(context: Context, downloader: Downloader, item: RomItem, onResult: (Boolean, String?) -> Unit) {
        if (selectedHost?.ip == null) {
            onResult(false, "No host selected")
            return
        }

        // Start the download
        downloader.download(context, item)
        
        // Wait for download and then transfer
        viewModelScope.launch(Dispatchers.IO) {
            val localFile = File(
                context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),
                "roms/${item.platform.id}/${item.displayName}"
            )
            
            // Poll for file existence with timeout
            var attempts = 0
            val maxAttempts = 60 // 60 seconds timeout
            
            while (!localFile.exists() && attempts < maxAttempts) {
                delay(1000) // Wait 1 second
                attempts++
            }
            
            if (!localFile.exists()) {
                withContext(Dispatchers.Main) {
                    onResult(false, "Download timeout - file not found after 60 seconds")
                }
                return@launch
            }
            
            // File exists, now transfer it using template credentials
            val hostIp = selectedHost?.ip ?: return@launch
            
            android.util.Log.d("RomTransfer", "=== TRANSFER DEBUG START ===")
            android.util.Log.d("RomTransfer", "Selected host IP: $hostIp")
            android.util.Log.d("RomTransfer", "Rocknix template IP: ${rocknixTemplate.hostIp}")
            android.util.Log.d("RomTransfer", "muOS template IP: ${muosTemplate.hostIp}")
            android.util.Log.d("RomTransfer", "Manual SSH settings - username: $sshUsername, port: $sshPort")
            
            // Use the connected template instead of IP matching
            val template = when (connectedTemplate) {
                "Rocknix" -> {
                    android.util.Log.d("RomTransfer", "✓ Using connected Rocknix template")
                    rocknixTemplate
                }
                "muOS" -> {
                    android.util.Log.d("RomTransfer", "✓ Using connected muOS template")
                    muosTemplate
                }
                else -> {
                    android.util.Log.d("RomTransfer", "⚠ No connected template, using manual settings")
                    android.util.Log.d("RomTransfer", "Connected template: '$connectedTemplate'")
                    HostTemplate(
                        name = "Manual",
                        username = sshUsername.ifEmpty { "root" },
                        password = if (useGuest) "" else sshPassword.ifEmpty { "root" },
                        port = sshPort.ifEmpty { "22" },
                        remoteBasePath = remoteBasePath.ifEmpty { "/storage/roms" },
                        hostIp = hostIp,
                        useGuest = useGuest,
                        isDhcpNetwork = isDhcpNetwork
                    )
                }
            }
            
            android.util.Log.d("RomTransfer", "Final template details:")
            android.util.Log.d("RomTransfer", "- Name: ${template.name}")
            android.util.Log.d("RomTransfer", "- Username: '${template.username}'")
            android.util.Log.d("RomTransfer", "- Password: '${template.password}' (length: ${template.password.length})")
            android.util.Log.d("RomTransfer", "- Port: '${template.port}'")
            android.util.Log.d("RomTransfer", "- Remote path: '${template.remoteBasePath}'")
            android.util.Log.d("RomTransfer", "=== TRANSFER DEBUG END ===")
            
            // Use template IP instead of selectedHost IP for template connections
            val actualHostIp = if (template.name != "Manual" && template.hostIp.isNotEmpty()) {
                android.util.Log.d("RomTransfer", "Using template IP: ${template.hostIp} instead of selected host: $hostIp")
                template.hostIp
            } else {
                android.util.Log.d("RomTransfer", "Using selected host IP: $hostIp")
                hostIp
            }
            
            val res = uploader.upload(
                localFile, 
                item.platform.id, 
                HostConfig(
                    host = actualHostIp, 
                    port = template.port.toIntOrNull() ?: 22, 
                    username = template.username.ifEmpty { "root" }, 
                    password = template.password
                ), 
                baseOverride = template.remoteBasePath.ifEmpty { "/storage/roms" }
            )
            val msg = res.exceptionOrNull()?.message ?: res.getOrNull() ?: ""
            Log.d("RomDL", "Download & Transfer result isSuccess=${res.isSuccess} pathOrError=${msg}")
            
            withContext(Dispatchers.Main) {
                if (res.isSuccess) {
                    onResult(true, "Downloaded and transferred to: ${msg}")
                } else {
                    val errorMsg = when {
                        msg.contains("failed to connect") -> "Cannot connect to device. Check IP address and network."
                        msg.contains("SSH auth failed") -> "Authentication failed. Check username/password."
                        msg.contains("timeout") -> "Connection timeout. Device may be unreachable."
                        else -> msg
                    }
                    onResult(false, errorMsg)
                }
            }
        }
    }

    fun downloadAndTransferAll(context: Context, downloader: Downloader, onProgress: (Int, Int, String) -> Unit, onComplete: (Int, Int) -> Unit) {
        if (selectedHost?.ip == null) {
            onProgress(0, 0, "No host selected")
            return
        }

        if (results.isEmpty()) {
            onProgress(0, 0, "No ROMs found to download")
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            val totalItems = results.size
            var successCount = 0
            var failureCount = 0

            withContext(Dispatchers.Main) {
                onProgress(0, totalItems, "Starting bulk download and transfer...")
            }

            for ((index, item) in results.withIndex()) {
                val currentProgress = index + 1
                
                withContext(Dispatchers.Main) {
                    onProgress(currentProgress, totalItems, "Processing: ${item.displayName}")
                }

                try {
                    // Start download
                    downloader.download(context, item)
                    
                    // Wait for download completion
                    val localFile = File(
                        context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),
                        "roms/${item.platform.id}/${item.displayName}"
                    )
                    
                    var attempts = 0
                    val maxAttempts = 120 // 2 minutes timeout for each file
                    
                    while (!localFile.exists() && attempts < maxAttempts) {
                        delay(1000)
                        attempts++
                    }
                    
                    if (!localFile.exists()) {
                        failureCount++
                        withContext(Dispatchers.Main) {
                            onProgress(currentProgress, totalItems, "Download timeout: ${item.displayName}")
                        }
                        continue
                    }
                    
                    // Transfer the file using connected template credentials
                    val hostIp = selectedHost?.ip ?: continue
                    
                    // Use the connected template instead of IP matching
                    val template = when (connectedTemplate) {
                        "Rocknix" -> {
                            android.util.Log.d("RomTransfer", "Bulk: Using connected Rocknix template")
                            rocknixTemplate
                        }
                        "muOS" -> {
                            android.util.Log.d("RomTransfer", "Bulk: Using connected muOS template")
                            muosTemplate
                        }
                        else -> {
                            android.util.Log.d("RomTransfer", "Bulk: No connected template, using manual settings")
                            HostTemplate(
                                name = "Manual",
                                username = sshUsername.ifEmpty { "root" },
                                password = if (useGuest) "" else sshPassword.ifEmpty { "root" },
                                port = sshPort.ifEmpty { "22" },
                                remoteBasePath = remoteBasePath.ifEmpty { "/storage/roms" },
                                hostIp = hostIp,
                                useGuest = useGuest,
                                isDhcpNetwork = isDhcpNetwork
                            )
                        }
                    }
                    
                    // Use template IP instead of selectedHost IP for template connections
                    val actualHostIp = if (template.name != "Manual" && template.hostIp.isNotEmpty()) {
                        android.util.Log.d("RomTransfer", "Bulk: Using template IP: ${template.hostIp}")
                        template.hostIp
                    } else {
                        android.util.Log.d("RomTransfer", "Bulk: Using selected host IP: $hostIp")
                        hostIp
                    }
                    
                    val res = uploader.upload(
                        localFile, 
                        item.platform.id, 
                        HostConfig(
                            host = actualHostIp, 
                            port = template.port.toIntOrNull() ?: 22, 
                            username = template.username.ifEmpty { "root" }, 
                            password = template.password
                        ), 
                        baseOverride = template.remoteBasePath.ifEmpty { "/storage/roms" }
                    )
                    
                    if (res.isSuccess) {
                        successCount++
                        withContext(Dispatchers.Main) {
                            onProgress(currentProgress, totalItems, "✓ Completed: ${item.displayName}")
                        }
                    } else {
                        failureCount++
                        withContext(Dispatchers.Main) {
                            onProgress(currentProgress, totalItems, "✗ Transfer failed: ${item.displayName}")
                        }
                    }
                    
                    // Small delay between transfers to avoid overwhelming the system
                    delay(500)
                    
                } catch (e: Exception) {
                    failureCount++
                    withContext(Dispatchers.Main) {
                        onProgress(currentProgress, totalItems, "✗ Error: ${item.displayName} - ${e.message}")
                    }
                }
            }

            withContext(Dispatchers.Main) {
                onComplete(successCount, failureCount)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RomApp(viewModel: MainViewModel, downloader: Downloader) {
    var selectedTab by remember { mutableStateOf(0) } // 0=Handheld, 1=Consoles (merged), 2=Custom Hosts
    var showConsoleSelect by remember { mutableStateOf(false) }
    
    Scaffold(
        bottomBar = {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.White),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CustomTabItem(
                        icon = com.example.romdownloader.R.drawable.home,
                        selectedIcon = com.example.romdownloader.R.drawable.home_selected,
                        label = "Home",
                        isSelected = selectedTab == 0,
                        onClick = { selectedTab = 0 }
                    )
                    CustomTabItem(
                        icon = com.example.romdownloader.R.drawable.search_nav,
                        selectedIcon = com.example.romdownloader.R.drawable.search_selected,
                        label = "Search",
                        isSelected = selectedTab == 1,
                    onClick = { 
                        selectedTab = 1
                        showConsoleSelect = true
                        }
                    )
                    
                    CustomTabItem(
                        icon = com.example.romdownloader.R.drawable.handhelds,
                        selectedIcon = com.example.romdownloader.R.drawable.handheld_selected,
                        label = "Handhelds",
                        isSelected = selectedTab == 2,
                        onClick = { selectedTab = 2 }
                    )
                    
                }
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)) {
            when (selectedTab) {
                0 -> HomeScreen(viewModel)
                1 -> {
                    if (showConsoleSelect) {
                        ConsoleSelectScreen(
                            viewModel = viewModel,
                            onConsoleSelected = { platform ->
                                viewModel.setPlatform(platform)
                                showConsoleSelect = false
                            }
                        )
                    } else {
                        BrowseScreen(viewModel, downloader)
                    }
                }
                2 -> HandheldScreen(viewModel)
                else -> HomeScreen(viewModel)
            }
        }
    }
}

@Composable
private fun CustomTabItem(
    icon: Int,
    selectedIcon: Int,
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .clickable { onClick() }
            .padding(vertical = 8.dp, horizontal = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            painter = painterResource(id = if (isSelected) selectedIcon else icon),
            contentDescription = label,
            tint = Color.Unspecified, // Use natural icon colors
            modifier = Modifier.size(24.dp)
        )
        
        Spacer(modifier = Modifier.height(4.dp))
        
        Text(
            text = label,
            color = Color(0xFF2F325A),
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Medium,
            fontSize = 12.sp
        )
    }
}

@Composable
private fun OldBrowseScreen(viewModel: MainViewModel, downloader: Downloader) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.Top) {
        Spacer(Modifier.height(8.dp))
        // Search row
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            var showPicker by remember { mutableStateOf(false) }
            var platformLabel by remember { mutableStateOf(viewModel.selectedPlatform?.label ?: "All Platforms") }

            Button(onClick = { showPicker = true }) { Text(platformLabel, style = MaterialTheme.typography.labelLarge) }
            if (showPicker) {
                AlertDialog(
                    onDismissRequest = { showPicker = false },
                    title = { Text("Select Console") },
                    text = {
                        LazyColumn(modifier = Modifier.fillMaxWidth()) {
                            item {
                                Button(onClick = {
                                    viewModel.setPlatform(null)
                                    platformLabel = "All Platforms"
                                    showPicker = false
                                }, modifier = Modifier.fillMaxWidth()) { Text("All Platforms") }
                            }
                            items(PlatformManager.all) { p ->
                                Button(onClick = {
                                    viewModel.setPlatform(p)
                                    platformLabel = p.label
                                    showPicker = false
                                }, modifier = Modifier.fillMaxWidth()) { Text(p.label) }
                            }
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = { showPicker = false }) { Text("Close") }
                    }
                )
            }

            OutlinedTextField(
                value = viewModel.searchTerm,
                onValueChange = { viewModel.updateSearchTerm(it) },
                label = { Text("Search") },
                modifier = Modifier.weight(1f)
            )

            Button(onClick = {
                if (viewModel.selectedPlatform == null) viewModel.searchAll() else viewModel.searchSelected()
            }) { Text("Search") }
        }
        Spacer(Modifier.height(8.dp))
        HorizontalDivider()
        Spacer(Modifier.height(8.dp))
        // Quick filter chips for common platforms
        LazyRow(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val quick = PlatformManager.all.take(5)
            items(quick) { p ->
                val selected = viewModel.selectedPlatform == p
                FilterChip(
                    selected = selected,
                    onClick = {
                        viewModel.setPlatform(if (selected) null else p)
                    },
                    label = { Text(p.label) }
                )
            }
        }

        Spacer(Modifier.height(12.dp))

        ResultsList(
            results = viewModel.results, 
            onDownload = { item ->
                downloader.download(context = ctx, item = item)
            }, 
            onUpload = { item ->
                val localFile = File(ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "roms/${item.platform.id}/${item.displayName}")
                viewModel.uploadFile(localFile, item.platform) { ok, remote ->
                    val msg = if (ok) "Uploaded to: ${remote ?: "unknown"}" else "Upload failed"
                    android.widget.Toast.makeText(ctx, msg, android.widget.Toast.LENGTH_LONG).show()
                }
            },
            onDownloadAndTransfer = if (viewModel.selectedHost != null) {
                { item ->
                    viewModel.downloadAndTransfer(ctx, downloader, item) { ok, message ->
                        val msg = if (ok) message ?: "Download and transfer completed" else "Download and transfer failed: ${message ?: "unknown error"}"
                        android.widget.Toast.makeText(ctx, msg, android.widget.Toast.LENGTH_LONG).show()
                    }
                }
            } else null
        )
    }
}

@Composable
fun ResultsList(
    results: List<RomItem>,
    onDownload: (RomItem) -> Unit,
    onUpload: (RomItem) -> Unit,
    onDownloadAndTransfer: ((RomItem) -> Unit)? = null
) {
    LazyColumn(modifier = Modifier.fillMaxSize()) {
        items(results) { item ->
            androidx.compose.material3.ListItem(
                headlineContent = { Text(item.displayName) },
                supportingContent = { Text(item.platform.label) },
                leadingContent = { androidx.compose.material3.Icon(Icons.Default.List, contentDescription = null) },
                trailingContent = {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        androidx.compose.material3.IconButton(onClick = { onDownload(item) }) {
                            androidx.compose.material3.Icon(Icons.Default.Download, contentDescription = "Download")
                        }
                        androidx.compose.material3.IconButton(onClick = { onUpload(item) }) {
                            androidx.compose.material3.Icon(Icons.Default.Send, contentDescription = "Upload")
                        }
                        if (onDownloadAndTransfer != null) {
                            androidx.compose.material3.IconButton(onClick = { onDownloadAndTransfer(item) }) {
                                androidx.compose.material3.Icon(Icons.Default.CheckCircle, contentDescription = "Download & Transfer")
                            }
                        }
                    }
                }
            )
        }
    }
}

@Composable
private fun OldHandheldScreen(viewModel: MainViewModel) {
    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.Top) {
        val appCtx = androidx.compose.ui.platform.LocalContext.current
        LaunchedEffect(Unit) { 
            viewModel.loadTemplates(appCtx)
            viewModel.initializePlatforms(appCtx)
        }
        var showTemplatesEditor by remember { mutableStateOf(false) }
        Spacer(Modifier.height(12.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Handheld", style = MaterialTheme.typography.titleLarge)
            TextButton(onClick = { showTemplatesEditor = true }) { Text("Edit templates") }
        }
        Spacer(Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Filled.Settings, contentDescription = null)
                        Text("Rocknix", style = MaterialTheme.typography.titleMedium)
                    }
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = { viewModel.applyTemplateRocknix(appCtx) }, modifier = Modifier.fillMaxWidth()) { Text("Connect") }
                }
            }
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Filled.Settings, contentDescription = null)
                        Text("muOS", style = MaterialTheme.typography.titleMedium)
                    }
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = { viewModel.applyTemplateMuOS(appCtx) }, modifier = Modifier.fillMaxWidth()) { Text("Connect") }
                }
            }
        }
        if (showTemplatesEditor) {
            androidx.compose.material3.AlertDialog(
                onDismissRequest = { showTemplatesEditor = false },
                title = { Text("Edit Templates") },
                text = {
                    // Local editable copies
                    var rock by remember(showTemplatesEditor) { mutableStateOf(viewModel.rocknixTemplate) }
                    var mu by remember(showTemplatesEditor) { mutableStateOf(viewModel.muosTemplate) }
                    LazyColumn(modifier = Modifier.fillMaxWidth()) {
                        item { Text("Rocknix", style = MaterialTheme.typography.titleMedium) }
                        item { Spacer(Modifier.height(8.dp)) }
                        item {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = rock.username,
                                    onValueChange = { rock = rock.copy(username = it) },
                                    label = { Text("Username") },
                                    modifier = Modifier.weight(1f)
                                )
                                OutlinedTextField(
                                    value = rock.password,
                                    onValueChange = { rock = rock.copy(password = it) },
                                    label = { Text("Password") },
                                    modifier = Modifier.weight(1f)
                                )
                                OutlinedTextField(
                                    value = rock.port,
                                    onValueChange = { rock = rock.copy(port = it.filter { ch -> ch.isDigit() }.take(5)) },
                                    label = { Text("Port") },
                                    modifier = Modifier.weight(0.6f)
                                )
                            }
                        }
                        item { Spacer(Modifier.height(8.dp)) }
                        item {
                            OutlinedTextField(
                                value = rock.remoteBasePath,
                                onValueChange = { rock = rock.copy(remoteBasePath = it) },
                                label = { Text("Remote base path") },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        item { Spacer(Modifier.height(8.dp)) }
                        item {
                            OutlinedTextField(
                                value = rock.hostIp,
                                onValueChange = { rock = rock.copy(hostIp = it) },
                                label = { Text("Host IP") },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        item { Spacer(Modifier.height(8.dp)) }
                        item {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                var rockGuest by remember(rock.useGuest) { mutableStateOf(rock.useGuest) }
                                Button(onClick = {
                                    rockGuest = !rockGuest
                                    rock = rock.copy(useGuest = rockGuest)
                                    if (rockGuest) rock = rock.copy(password = "")
                                }) { Text(if (rockGuest) "Guest: ON" else "Guest: OFF") }
                                var rockDhcp by remember(rock.isDhcpNetwork) { mutableStateOf(rock.isDhcpNetwork) }
                                Button(onClick = {
                                    rockDhcp = !rockDhcp
                                    rock = rock.copy(isDhcpNetwork = rockDhcp)
                                }) { Text(if (rockDhcp) "DHCP" else "Manual") }
                            }
                        }
                        item { Spacer(Modifier.height(8.dp)) }
                        item { Button(onClick = { viewModel.updateTemplate(appCtx, rock) }) { Text("Save Rocknix") } }

                        item { Spacer(Modifier.height(16.dp)) }
                        item { Text("muOS", style = MaterialTheme.typography.titleMedium) }
                        item { Spacer(Modifier.height(8.dp)) }
                        item {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = mu.username,
                                    onValueChange = { mu = mu.copy(username = it) },
                                    label = { Text("Username") },
                                    modifier = Modifier.weight(1f)
                                )
                                OutlinedTextField(
                                    value = mu.password,
                                    onValueChange = { mu = mu.copy(password = it) },
                                    label = { Text("Password") },
                                    modifier = Modifier.weight(1f)
                                )
                                OutlinedTextField(
                                    value = mu.port,
                                    onValueChange = { mu = mu.copy(port = it.filter { ch -> ch.isDigit() }.take(5)) },
                                    label = { Text("Port") },
                                    modifier = Modifier.weight(0.6f)
                                )
                            }
                        }
                        item { Spacer(Modifier.height(8.dp)) }
                        item {
                            OutlinedTextField(
                                value = mu.remoteBasePath,
                                onValueChange = { mu = mu.copy(remoteBasePath = it) },
                                label = { Text("Remote base path") },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        item { Spacer(Modifier.height(8.dp)) }
                        item {
                            OutlinedTextField(
                                value = mu.hostIp,
                                onValueChange = { mu = mu.copy(hostIp = it) },
                                label = { Text("Host IP") },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        item { Spacer(Modifier.height(8.dp)) }
                        item {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                var muGuest by remember(mu.useGuest) { mutableStateOf(mu.useGuest) }
                                Button(onClick = {
                                    muGuest = !muGuest
                                    mu = mu.copy(useGuest = muGuest)
                                    if (muGuest) mu = mu.copy(password = "")
                                }) { Text(if (muGuest) "Guest: ON" else "Guest: OFF") }
                                var muDhcp by remember(mu.isDhcpNetwork) { mutableStateOf(mu.isDhcpNetwork) }
                                Button(onClick = {
                                    muDhcp = !muDhcp
                                    mu = mu.copy(isDhcpNetwork = muDhcp)
                                }) { Text(if (muDhcp) "DHCP" else "Manual") }
                            }
                        }
                        item { Spacer(Modifier.height(8.dp)) }
                        item { Button(onClick = { viewModel.updateTemplate(appCtx, mu) }) { Text("Save muOS") } }
                    }
                },
                confirmButton = { TextButton(onClick = { showTemplatesEditor = false }) { Text("Close") } }
            )
        }
    }
}

@Composable
private fun CustomHostsScreen(viewModel: MainViewModel) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            // Network page title
            Text(
                text = "Network",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )
        }

        
        item {
            // Host Discovery Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                    ) {
                        Text("Host Discovery", style = MaterialTheme.typography.titleMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { viewModel.scanHosts() },
                                shape = RoundedCornerShape(12.dp)
                            ) { 
                                Text(if (viewModel.isScanning) "Scanning..." else "Scan") 
                            }
                            val ctx = androidx.compose.ui.platform.LocalContext.current
                            Button(
                                onClick = {
                                    val ip = viewModel.selectedHost?.ip
                                    if (ip == null) {
                                        android.widget.Toast.makeText(ctx, "No host selected", android.widget.Toast.LENGTH_SHORT).show()
                                    } else {
                                        viewModel.viewModelScope.launch(Dispatchers.IO) {
                                            val resultText = try {
                                                val port = viewModel.sshPort.toIntOrNull() ?: 22
                                                val username = if (viewModel.useGuest) viewModel.sshUsername.ifEmpty { "root" } else viewModel.sshUsername.ifEmpty { "root" }
                                                val password = if (viewModel.useGuest) "" else viewModel.sshPassword
                                                com.example.romdownloader.network.SshTester().test(HostConfig(host = ip, port = port, username = username, password = password)).getOrThrow()
                                            } catch (t: Throwable) {
                                                val err = t.message ?: "Connection failed"
                                                Log.e("RomDL", "Test connection failed", t)
                                                err
                                            }
                                            withContext(Dispatchers.Main) {
                                                val shortMsg = resultText.take(80)
                                                android.widget.Toast.makeText(ctx, shortMsg, android.widget.Toast.LENGTH_LONG).show()
                                            }
                                        }
                                    }
                                },
                                shape = RoundedCornerShape(12.dp)
                            ) { 
                                Text("Test") 
                            }
                        }
                    }
                    
                    // Manual IP entry
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                    ) {
                        var ip by remember { mutableStateOf("") }
                        OutlinedTextField(
                            value = ip,
                            onValueChange = { ip = it },
                            label = { Text("Host IP Address") },
                            placeholder = { Text("192.168.0.159") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        )
                        Button(
                            onClick = { viewModel.addHostFromIp(ip) },
                            shape = RoundedCornerShape(12.dp)
                        ) { 
                            Text("Add") 
                        }
                    }
                }
            }
        }
        
        item {
            // SSH Configuration Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("SSH Configuration", style = MaterialTheme.typography.titleMedium)
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = viewModel.sshUsername,
                            onValueChange = { viewModel.sshUsername = it },
                            label = { Text("Username") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        )
                        OutlinedTextField(
                            value = viewModel.sshPassword,
                            onValueChange = { viewModel.sshPassword = it },
                            label = { Text("Password") },
                            placeholder = { Text("Leave blank for guest") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        )
                        OutlinedTextField(
                            value = viewModel.sshPort,
                            onValueChange = { viewModel.sshPort = it.filter { ch -> ch.isDigit() }.take(5) },
                            label = { Text("Port") },
                            placeholder = { Text("22") },
                            modifier = Modifier.weight(0.6f),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                    
                    // Settings toggles
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                            var guest by remember { mutableStateOf(viewModel.useGuest) }
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                            ) {
                                Text("Guest Mode", style = MaterialTheme.typography.bodyMedium)
                                Switch(
                                    checked = guest, 
                                    onCheckedChange = {
                                        guest = it
                                        viewModel.useGuest = it
                                        if (it) viewModel.sshPassword = ""
                                    }
                                )
                            }
                            var dhcp by remember { mutableStateOf(viewModel.isDhcpNetwork) }
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                            ) {
                                Text("DHCP Network", style = MaterialTheme.typography.bodyMedium)
                                Switch(
                                    checked = dhcp, 
                                    onCheckedChange = {
                                        dhcp = it
                                        viewModel.isDhcpNetwork = it
                                    }
                                )
                            }
                        }
                        val ctx2 = androidx.compose.ui.platform.LocalContext.current
                        Button(
                            onClick = {
                                val ip = viewModel.selectedHost?.ip
                                val port = viewModel.sshPort
                                val user = viewModel.sshUsername
                                android.widget.Toast.makeText(ctx2, "Using $user@$ip:$port", android.widget.Toast.LENGTH_SHORT).show()
                            },
                            shape = RoundedCornerShape(12.dp)
                        ) { 
                            Text("Apply") 
                        }
                    }
                    
                    // Remote path
                    OutlinedTextField(
                        value = viewModel.remoteBasePath,
                        onValueChange = { viewModel.remoteBasePath = it },
                        label = { Text("Remote Base Path") },
                        placeholder = { Text("/roms or /mnt/mmc/ROMS") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            }
        }
        
        item {
            // Discovered Hosts Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("Discovered Hosts", style = MaterialTheme.typography.titleMedium)
                    
                    if (viewModel.hosts.isEmpty()) {
                        Text(
                            "No hosts found. Use the Scan button to discover devices on your network.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    } else {
                        viewModel.hosts.forEach { host ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (viewModel.selectedHost == host) 
                                        com.example.romdownloader.ui.theme.Purple.copy(alpha = 0.1f)
                                    else 
                                        MaterialTheme.colorScheme.surface
                                ),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                                ) {
                                    Text(host.ip, style = MaterialTheme.typography.bodyLarge)
                                    Button(
                                        onClick = { viewModel.selectHost(host) },
                                        shape = RoundedCornerShape(8.dp),
                                        colors = if (viewModel.selectedHost == host) 
                                            ButtonDefaults.buttonColors(containerColor = com.example.romdownloader.ui.theme.Purple)
                                        else 
                                            ButtonDefaults.buttonColors()
                                    ) { 
                                        Text(if (viewModel.selectedHost == host) "Selected" else "Select") 
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

object LocalAppContext {
    val current: Context
        @Composable get() = androidx.compose.ui.platform.LocalContext.current
}

package com.example.romdownloader.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.romdownloader.MainViewModel
import com.example.romdownloader.R
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HandheldScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    var showConnectionDialog by remember { mutableStateOf(false) }
    var showEditDialog by remember { mutableStateOf(false) }
    var selectedTemplate by remember { mutableStateOf<String?>(null) }
    var connectionStatus by remember { mutableStateOf<Map<String, Boolean>>(emptyMap()) }
    
    // Only update connection status when user explicitly tests connection
    // Don't automatically show connected state based on persisted template
    
    LaunchedEffect(Unit) { 
        viewModel.loadTemplates(context) 
        viewModel.initializePlatforms(context)
        
        // Don't automatically set connection status - let user test connection first
        // This ensures muOS template starts with "CONNECT" button by default
    }
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFAFAFA))
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Modern Header
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(top = 48.dp, bottom = 24.dp, start = 20.dp, end = 20.dp)
            ) {
                Text(
                    text = "Handhelds",
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1F2937),
                    fontSize = 32.sp
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Text(
                    text = "Connect to your handheld device",
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color(0xFF9CA3AF),
                    fontSize = 16.sp
                )
            }
            
            // Connection Cards Section
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 20.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Rocknix Card (no subtitle, with edit)
                item {
                    EnhancedConnectionCard(
                        title = "Rocknix",
                        subtitle = null,
                        isConnected = connectionStatus["Rocknix"] ?: false,
                        showEditButton = true,
                        connectionStatus = connectionStatus,
                        onConnect = { 
                            selectedTemplate = "Rocknix"
                            showConnectionDialog = true
                        },
                        onEdit = {
                            selectedTemplate = "Rocknix"
                            showEditDialog = true
                        }
                    )
                }
                
                // muOS Card (no subtitle, with edit)
                item {
                    EnhancedConnectionCard(
                        title = "muOS",
                        subtitle = null,
                        isConnected = connectionStatus["muOS"] ?: false,
                        showEditButton = true,
                        connectionStatus = connectionStatus,
                        onConnect = {
                            selectedTemplate = "muOS"
                            showConnectionDialog = true
                        },
                        onEdit = {
                            selectedTemplate = "muOS"
                            showEditDialog = true
                        }
                    )
                }
                
                // Manual Configuration Card (with subtitle, no edit)
                item {
                    EnhancedConnectionCard(
                        title = "Manual Configuration",
                        subtitle = "Set up custom connection settings",
                        isConnected = false,
                        showEditButton = false,
                        connectionStatus = connectionStatus,
                        onConnect = {
                            selectedTemplate = "Manual"
                            showConnectionDialog = true
                        },
                        onEdit = {}
                    )
                }
            }
        }
    }
    
    // Connection Dialog
    if (showConnectionDialog && selectedTemplate != null) {
        ConnectionDialog(
            templateName = selectedTemplate!!,
            viewModel = viewModel,
            context = context,
            onDismiss = { showConnectionDialog = false },
            onConnected = { templateName, success ->
                connectionStatus = connectionStatus + (templateName to success)
            }
        )
    }
    
    // Edit Dialog
    if (showEditDialog && selectedTemplate != null) {
        EditTemplateDialog(
            templateName = selectedTemplate!!,
            viewModel = viewModel,
            context = context,
            onDismiss = { showEditDialog = false }
        )
    }
}

@Composable
private fun EnhancedConnectionCard(
    title: String,
    subtitle: String?,
    isConnected: Boolean,
    showEditButton: Boolean,
    connectionStatus: Map<String, Boolean>,
    onConnect: () -> Unit,
    onEdit: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(1.dp, RoundedCornerShape(12.dp)),
        onClick = onConnect,
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFFF8F9FA)
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                // Platform icon using Search_platform image
                Icon(
                    painter = painterResource(id = R.drawable.search_platform),
                    contentDescription = null,
                    modifier = Modifier.size(48.dp),
                    tint = Color.Unspecified
                )
                
                Spacer(modifier = Modifier.width(16.dp))
                
                Column {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF111827),
                        fontSize = 16.sp
                    )
                    
                    // Only show subtitle if provided
                    if (subtitle != null) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = subtitle,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF9CA3AF),
                            fontSize = 14.sp
                        )
                    }
                }
            }
            
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Edit button for Rocknix and muOS
                if (showEditButton) {
                    IconButton(
                        onClick = onEdit,
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(
                            painter = painterResource(id = R.drawable.edit_18_new),
                            contentDescription = "Edit",
                            tint = Color(0xFF6B7280),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
                
                // Connect button with three states: Connect (blue), Connected (green), Failed (red)
                if (title != "Manual Configuration") {
                    val connectionState = connectionStatus[title]
                    val (buttonColor, buttonText) = when (connectionState) {
                        true -> Color(0xFF10B981) to "CONNECTED"  // Green for success
                        false -> Color(0xFFEF4444) to "FAILED"    // Red for failure
                        null -> Color(0xFF4AB5FB) to "CONNECT"    // Blue for not tested
                    }
                    
                    Button(
                        onClick = onConnect,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = buttonColor
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.height(40.dp)
                    ) {
                        Text(
                            buttonText,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                } else {
                    IconButton(
                        onClick = onConnect,
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(
                            painter = painterResource(id = R.drawable.edit_18),
                            contentDescription = "Configure",
                            tint = Color(0xFF6B7280),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ConnectionDialog(
    templateName: String,
    viewModel: MainViewModel,
    context: android.content.Context,
    onDismiss: () -> Unit,
    onConnected: (String, Boolean) -> Unit
) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var remotePath by remember { mutableStateOf("") }
    var port by remember { mutableStateOf("") }
    
    // Load template values
    LaunchedEffect(templateName) {
        when (templateName) {
            "Rocknix" -> {
                val template = viewModel.rocknixTemplate
                username = template.username
                password = template.password
                remotePath = template.remoteBasePath
                port = template.port
            }
            "muOS" -> {
                val template = viewModel.muosTemplate
                username = template.username
                password = template.password
                remotePath = template.remoteBasePath
                port = template.port
            }
            else -> {
                username = "root"
                password = ""
                remotePath = "/storage/roms"
                port = "22"
            }
        }
    }
    
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = Color.White
            )
        ) {
            Column(
                modifier = Modifier.padding(24.dp)
            ) {
                Text(
                    text = templateName.uppercase(),
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF1F2937),
                    fontSize = 18.sp
                )
                
                Spacer(modifier = Modifier.height(20.dp))
                
                // Username Field
                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it },
                    label = { Text("Username") },
                    placeholder = { Text("Username") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF6366F1),
                        unfocusedBorderColor = Color(0xFFE5E7EB),
                        focusedTextColor = Color(0xFF111827),
                        unfocusedTextColor = Color(0xFF111827),
                        cursorColor = Color(0xFF6366F1)
                    ),
                    shape = RoundedCornerShape(12.dp)
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Password Field
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Password") },
                    placeholder = { Text("Password") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF6366F1),
                        unfocusedBorderColor = Color(0xFFE5E7EB),
                        focusedTextColor = Color(0xFF111827),
                        unfocusedTextColor = Color(0xFF111827),
                        cursorColor = Color(0xFF6366F1)
                    ),
                    shape = RoundedCornerShape(12.dp)
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Remote Path and Port Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = remotePath,
                        onValueChange = { remotePath = it },
                        label = { Text("Remote path") },
                        placeholder = { Text("/storage/roms") },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF6366F1),
                            unfocusedBorderColor = Color(0xFFE5E7EB),
                            focusedTextColor = Color(0xFF111827),
                            unfocusedTextColor = Color(0xFF111827),
                            cursorColor = Color(0xFF6366F1)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )
                    
                    OutlinedTextField(
                        value = port,
                        onValueChange = { port = it },
                        label = { Text("Port") },
                        placeholder = { Text("22") },
                        modifier = Modifier.width(80.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF6366F1),
                            unfocusedBorderColor = Color(0xFFE5E7EB),
                            focusedTextColor = Color(0xFF111827),
                            unfocusedTextColor = Color(0xFF111827),
                            cursorColor = Color(0xFF6366F1)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )
                }
                
                Spacer(modifier = Modifier.height(24.dp))
                
                // Scan Network Button
                Button(
                    onClick = {
                        // Apply the template and scan network
                        when (templateName) {
                            "Rocknix" -> viewModel.applyTemplateRocknix(context)
                            "muOS" -> viewModel.applyTemplateMuOS(context)
                            "Manual" -> {
                                // Save manual settings
                                viewModel.sshUsername = username
                                viewModel.sshPassword = password
                                viewModel.sshPort = port
                                viewModel.remoteBasePath = remotePath
                                viewModel.updateConnectedTemplate("Manual")
                                viewModel.saveManualSettings(context)
                            }
                        }
                        viewModel.scanHosts()
                        
                        // Test actual connection to the specific IP
                        val template = when (templateName) {
                            "Rocknix" -> viewModel.rocknixTemplate
                            "muOS" -> viewModel.muosTemplate
                            else -> null
                        }
                        
                        if (template != null && template.hostIp.isNotEmpty()) {
                            // Test actual SSH connection
                            viewModel.testConnection(
                                hostIp = template.hostIp,
                                username = template.username,
                                password = template.password,
                                port = template.port.toIntOrNull() ?: 22,
                                onResult = { success ->
                                    onConnected(templateName, success)
                                }
                            )
                        } else {
                            // No IP configured, show as not connected
                            onConnected(templateName, false)
                        }
                        
                        onDismiss()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF4AB5FB)
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        "SCAN NETWORK",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
                
                Spacer(modifier = Modifier.height(12.dp))
                
                // Cancel Button
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        "CANCEL",
                        color = Color(0xFF6B7280),
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EditTemplateDialog(
    templateName: String,
    viewModel: MainViewModel,
    context: android.content.Context,
    onDismiss: () -> Unit
) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var remotePath by remember { mutableStateOf("") }
    var hostIp by remember { mutableStateOf("") }
    
    // Load current template values
    LaunchedEffect(templateName) {
        val template = when (templateName) {
            "Rocknix" -> viewModel.rocknixTemplate
            "muOS" -> viewModel.muosTemplate
            else -> return@LaunchedEffect
        }
        username = template.username
        password = template.password
        remotePath = template.remoteBasePath
        hostIp = template.hostIp
    }
    
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(
                modifier = Modifier.padding(24.dp)
            ) {
                Text(
                    text = "EDIT ${templateName.uppercase()}",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF111827),
                    fontSize = 18.sp
                )
                
                Spacer(modifier = Modifier.height(20.dp))
                
                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it },
                    label = { Text("Username") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color(0xFF111827),
                        unfocusedTextColor = Color(0xFF111827),
                        cursorColor = Color(0xFF6366F1)
                    ),
                    shape = RoundedCornerShape(12.dp)
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Password") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color(0xFF111827),
                        unfocusedTextColor = Color(0xFF111827),
                        cursorColor = Color(0xFF6366F1)
                    ),
                    shape = RoundedCornerShape(12.dp)
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                OutlinedTextField(
                    value = hostIp,
                    onValueChange = { hostIp = it },
                    label = { Text("Host IP") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color(0xFF111827),
                        unfocusedTextColor = Color(0xFF111827),
                        cursorColor = Color(0xFF6366F1)
                    ),
                    shape = RoundedCornerShape(12.dp)
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                OutlinedTextField(
                    value = remotePath,
                    onValueChange = { remotePath = it },
                    label = { Text("Remote Path") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color(0xFF111827),
                        unfocusedTextColor = Color(0xFF111827),
                        cursorColor = Color(0xFF6366F1)
                    ),
                    shape = RoundedCornerShape(12.dp)
                )
                
                Spacer(modifier = Modifier.height(24.dp))
                
                Button(
                    onClick = {
                        val updatedTemplate = when (templateName) {
                            "Rocknix" -> viewModel.rocknixTemplate.copy(
                                username = username,
                                password = password,
                                hostIp = hostIp,
                                remoteBasePath = remotePath
                            )
                            "muOS" -> viewModel.muosTemplate.copy(
                                username = username,
                                password = password,
                                hostIp = hostIp,
                                remoteBasePath = remotePath
                            )
                            else -> return@Button
                        }
                        viewModel.updateTemplate(context, updatedTemplate)
                        onDismiss()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4AB5FB))
                ) {
                    Text("SAVE", color = Color.White, fontWeight = FontWeight.Bold)
                }
                
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("CANCEL", color = Color(0xFF6B7280), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

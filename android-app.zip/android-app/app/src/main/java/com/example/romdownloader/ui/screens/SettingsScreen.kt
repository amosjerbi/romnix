package com.example.romdownloader.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.romdownloader.Platform
import com.example.romdownloader.PlatformManager
import com.example.romdownloader.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onBackPressed: () -> Unit
) {
    val context = LocalContext.current
    var showAddDialog by remember { mutableStateOf(false) }
    var editingPlatform by remember { mutableStateOf<Platform?>(null) }
    var refreshTrigger by remember { mutableStateOf(0) }
    
    // Force recomposition when platforms change
    LaunchedEffect(refreshTrigger) {
        PlatformManager.loadCustomPlatforms(context)
    }
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFAFAFA))
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Modern Header with gradient background
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        brush = androidx.compose.ui.graphics.Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFF6366F1),
                                Color(0xFF8B5CF6)
                            )
                        )
                    )
                    .padding(top = 48.dp, bottom = 24.dp, start = 20.dp, end = 20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onBackPressed,
                        modifier = Modifier
                            .background(
                                Color.White.copy(alpha = 0.2f),
                                RoundedCornerShape(12.dp)
                            )
                            .size(44.dp)
                    ) {
                        Icon(
                            Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "Platform Links",
                            style = MaterialTheme.typography.headlineLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 24.sp
                        )
                        Text(
                            text = "Manage your ROM sources",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White.copy(alpha = 0.8f),
                            fontSize = 14.sp
                        )
                    }
                    
                    // Add Button
                    IconButton(
                        onClick = { showAddDialog = true },
                        modifier = Modifier
                            .background(
                                Color.White.copy(alpha = 0.2f),
                                RoundedCornerShape(12.dp)
                            )
                            .size(44.dp)
                    ) {
                        Icon(
                            Icons.Default.Add,
                            contentDescription = "Add Platform",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
            
            // Platforms List Section
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                if (PlatformManager.all.isEmpty()) {
                    // Modern Empty State
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .shadow(2.dp, RoundedCornerShape(20.dp)),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(40.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                painter = painterResource(id = R.drawable.romnix_emptystate),
                                contentDescription = null,
                                modifier = Modifier.size(80.dp),
                                tint = Color(0xFFE5E7EB)
                            )
                            
                            Spacer(modifier = Modifier.height(16.dp))
                            
                            Text(
                                text = "No Platform Links",
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF374151),
                                fontSize = 20.sp
                            )
                            
                            Spacer(modifier = Modifier.height(8.dp))
                            
                            Text(
                                text = "Add your first custom platform to start downloading ROMs",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color(0xFF9CA3AF),
                                textAlign = TextAlign.Center,
                                fontSize = 14.sp
                            )
                            
                            Spacer(modifier = Modifier.height(20.dp))
                            
                            Button(
                                onClick = { showAddDialog = true },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF6366F1)
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(
                                    Icons.Default.Add,
                                    contentDescription = null,
                                    tint = Color.White
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    "Add Platform Link",
                                    color = Color.White,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        items(PlatformManager.all) { platform ->
                            ModernPlatformItem(
                                platform = platform,
                                onEdit = if (platform.isCustom) {
                                    { editingPlatform = platform }
                                } else null,
                                onDelete = if (platform.isCustom) {
                                    {
                                        PlatformManager.removeCustomPlatform(context, platform.id)
                                        refreshTrigger++
                                    }
                                } else null
                            )
                        }
                        
                        // Add button at the end of the list
                        item {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .shadow(2.dp, RoundedCornerShape(16.dp)),
                                onClick = { showAddDialog = true },
                                colors = CardDefaults.cardColors(
                                    containerColor = Color(0xFF6366F1).copy(alpha = 0.1f)
                                ),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(20.dp),
                                    horizontalArrangement = Arrangement.Center,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Default.Add,
                                        contentDescription = null,
                                        tint = Color(0xFF6366F1),
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        "Add New Platform",
                                        style = MaterialTheme.typography.bodyLarge,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color(0xFF6366F1),
                                        fontSize = 16.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    // Add/Edit dialog
    if (showAddDialog || editingPlatform != null) {
        PlatformEditDialog(
            platform = editingPlatform,
            onDismiss = {
                showAddDialog = false
                editingPlatform = null
            },
            onSave = { platform ->
                if (editingPlatform != null) {
                    PlatformManager.updateCustomPlatform(context, platform)
                } else {
                    PlatformManager.addCustomPlatform(context, platform)
                }
                showAddDialog = false
                editingPlatform = null
                refreshTrigger++
            }
        )
    }
}

@Composable
private fun ModernPlatformItem(
    platform: Platform,
    onEdit: (() -> Unit)? = null,
    onDelete: (() -> Unit)? = null
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(2.dp, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    // Platform Icon with background
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .background(
                                Color(0xFF6366F1).copy(alpha = 0.1f),
                                RoundedCornerShape(12.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            when (platform.id) {
                                "nes", "snes", "genesis" -> Icons.Default.SportsEsports
                                "gb", "gba", "gbc", "gamegear", "ngp" -> Icons.Default.Gamepad
                                "n64", "ps1", "dreamcast", "saturn", "tg16" -> Icons.Default.VideogameAsset
                                else -> Icons.Default.Games
                            },
                            contentDescription = null,
                            tint = Color(0xFF6366F1),
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    
                    Spacer(modifier = Modifier.width(16.dp))
                    
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = platform.label,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1F2937),
                                fontSize = 16.sp
                            )
                            
                            if (platform.isCustom) {
                                Spacer(modifier = Modifier.width(8.dp))
                                Surface(
                                    color = Color(0xFF6366F1).copy(alpha = 0.1f),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = "Custom",
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF6366F1),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                        
                        if (platform.archiveUrl.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = platform.archiveUrl,
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF9CA3AF),
                                maxLines = 1,
                                fontSize = 12.sp
                            )
                        }
                        
                        if (platform.extensions.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Extensions: ${platform.extensions.joinToString(", ")}",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFFD1D5DB),
                                fontSize = 11.sp
                            )
                        }
                    }
                }
                
                if (platform.isCustom) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        if (onEdit != null) {
                            IconButton(
                                onClick = onEdit,
                                modifier = Modifier.size(40.dp)
                            ) {
                                Icon(
                                    painter = painterResource(id = R.drawable.edit_18),
                                    contentDescription = "Edit",
                                    tint = Color(0xFF6366F1),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                        if (onDelete != null) {
                            IconButton(
                                onClick = onDelete,
                                modifier = Modifier.size(40.dp)
                            ) {
                                Icon(
                                    painter = painterResource(id = R.drawable.trash_18),
                                    contentDescription = "Delete",
                                    tint = Color(0xFFEF4444),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PlatformEditDialog(
    platform: Platform?,
    onDismiss: () -> Unit,
    onSave: (Platform) -> Unit
) {
    var name by remember { mutableStateOf(platform?.label ?: "") }
    var url by remember { mutableStateOf(platform?.archiveUrl ?: "") }
    var extensions by remember { mutableStateOf(platform?.extensions?.joinToString(", ") ?: "gbc, 7z, zip") }
    var showUrlError by remember { mutableStateOf(false) }
    var showNameError by remember { mutableStateOf(false) }
    
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = Color.White
            )
        ) {
            Column(
                modifier = Modifier.padding(24.dp)
            ) {
                Text(
                    text = if (platform != null) "Edit Platform" else "Add Custom Platform",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
                
                OutlinedTextField(
                    value = name,
                    onValueChange = { 
                        name = it
                        showNameError = false
                    },
                    label = { Text("Platform Name") },
                    placeholder = { Text("e.g., NES, SNES, Genesis") },
                    modifier = Modifier.fillMaxWidth(),
                    isError = showNameError,
                    supportingText = if (showNameError) {
                        { Text("Platform name is required") }
                    } else null
                )
                
                Spacer(modifier = Modifier.height(12.dp))
                
                OutlinedTextField(
                    value = url,
                    onValueChange = { 
                        url = it
                        showUrlError = false
                    },
                    label = { Text("Archive URL") },
                    placeholder = { Text("https://example.com/roms/platform/") },
                    modifier = Modifier.fillMaxWidth(),
                    isError = showUrlError,
                    supportingText = if (showUrlError) {
                        { Text("Valid URL is required") }
                    } else null
                )
                
                Spacer(modifier = Modifier.height(12.dp))
                
                OutlinedTextField(
                    value = extensions,
                    onValueChange = { extensions = it },
                    label = { Text("File Extensions") },
                    placeholder = { Text("gbc, 7z, zip") },
                    modifier = Modifier.fillMaxWidth(),
                    supportingText = { Text("Comma-separated list of file extensions (without dots)") }
                )
                
                Spacer(modifier = Modifier.height(24.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Cancel")
                    }
                    
                    Button(
                        onClick = {
                            val trimmedName = name.trim()
                            val trimmedUrl = url.trim()
                            
                            showNameError = trimmedName.isEmpty()
                            showUrlError = trimmedUrl.isEmpty() || !trimmedUrl.startsWith("http")
                            
                            if (!showNameError && !showUrlError) {
                                val extensionsList = extensions.split(",").map { it.trim() }.filter { it.isNotEmpty() }
                                val id = platform?.id ?: trimmedName.lowercase().replace(" ", "")
                                
                                onSave(
                                    Platform(
                                        id = id,
                                        label = trimmedName,
                                        archiveUrl = trimmedUrl,
                                        extensions = extensionsList.ifEmpty { listOf("7z", "zip") },
                                        isCustom = true
                                    )
                                )
                            }
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6366F1))
                    ) {
                        Text("Save")
                    }
                }
            }
        }
    }
}

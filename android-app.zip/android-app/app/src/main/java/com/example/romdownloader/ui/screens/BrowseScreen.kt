package com.example.romdownloader.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import android.widget.Toast
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.romdownloader.Downloader
import com.example.romdownloader.MainViewModel
import com.example.romdownloader.Platform
import com.example.romdownloader.PlatformManager
import com.example.romdownloader.RomItem
import com.example.romdownloader.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrowseScreen(
    viewModel: MainViewModel,
    downloader: Downloader
) {
    val context = LocalContext.current
    var selectedPlatform by remember { mutableStateOf(viewModel.selectedPlatform) }
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Header
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(top = 48.dp, bottom = 24.dp, start = 20.dp, end = 20.dp)
            ) {
                Text(
                    text = "Browse ROMs",
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF111827),
                    fontSize = 32.sp
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Text(
                    text = "Select platforms you added",
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF9CA3AF),
                    fontSize = 16.sp
                )
            }
            
            // Search Section
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Search Field
                    OutlinedTextField(
                        value = viewModel.searchTerm,
                        onValueChange = { viewModel.updateSearchTerm(it) },
                        modifier = Modifier.weight(1f),
                    placeholder = { 
                        Text(
                            "Search ROMs...",
                            color = Color(0xFF9CA3AF),
                            fontWeight = FontWeight.Medium
                        ) 
                    },
                    trailingIcon = if (viewModel.searchTerm.isNotEmpty()) {
                        {
                                IconButton(onClick = { viewModel.updateSearchTerm("") }) {
                                    Icon(
                                    Icons.Default.Close,
                                        contentDescription = "Clear",
                                    tint = Color(0xFF6B7280),
                                    modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                    } else null,
                        colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF2F325A),
                        unfocusedBorderColor = Color(0xFFE5E7EB),
                        cursorColor = Color(0xFF2F325A),
                        focusedTextColor = Color(0xFF2F325A),
                        unfocusedTextColor = Color(0xFF2F325A)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                    
                // Blue Search Button
                FloatingActionButton(
                        onClick = {
                        if (selectedPlatform != null) {
                                viewModel.searchSelected()
                        } else {
                            viewModel.searchAll()
                        }
                    },
                    containerColor = Color(0xFF4AB5FB),
                    contentColor = Color.White,
                    modifier = Modifier.size(56.dp),
                    elevation = FloatingActionButtonDefaults.elevation(
                        defaultElevation = 0.dp,
                        pressedElevation = 0.dp
                    )
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.search),
                        contentDescription = "Search",
                        modifier = Modifier.size(24.dp),
                        tint = Color.White
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Platform Filter Chips
            if (selectedPlatform != null) {
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        FilterChip(
                            selected = true,
                            onClick = {
                                selectedPlatform = null
                                viewModel.setPlatform(null)
                            },
                            label = { 
                                Text(
                                    selectedPlatform!!.label,
                                    fontWeight = FontWeight.Medium
                                ) 
                            },
                            trailingIcon = {
                                Icon(
                                    Icons.Default.Close,
                                    contentDescription = "Clear",
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFF6366F1).copy(alpha = 0.1f),
                                selectedLabelColor = Color(0xFF6366F1)
                            )
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
            }
            
            // ROM Results
            if (viewModel.isSearching) {
                // Loading State
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(
                        color = Color(0xFF6366F1)
                    )
                }
            } else if (viewModel.results.isEmpty()) {
                // No Results
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No ROMs found",
                        style = MaterialTheme.typography.bodyLarge,
                        color = Color(0xFF9CA3AF)
                    )
                }
            } else {
                Column {
                    // Bulk Download Card (when multiple results)
                    if (viewModel.results.size > 1) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                                .padding(horizontal = 20.dp)
                                .shadow(1.dp, RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(
                                containerColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                        text = "Bulk Download",
                                        style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Bold,
                                        color = Color(0xFF111827),
                                        fontSize = 16.sp
                            )
                                    
                                    Spacer(modifier = Modifier.height(4.dp))
                                    
                            Text(
                                        text = "${viewModel.results.size} ROMs found",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Medium,
                                        color = Color(0xFF9CA3AF),
                                        fontSize = 12.sp
                                    )
                                }
                                
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    // Bulk Download Button (Green)
                                    FloatingActionButton(
                                        onClick = {
                                            viewModel.results.forEach { rom ->
                                                downloader.download(context, rom)
                                            }
                                            Toast.makeText(context, "Downloading ${viewModel.results.size} ROMs...", Toast.LENGTH_LONG).show()
                                        },
                                        containerColor = Color(0xFF42B846),
                                        contentColor = Color.White,
                                        modifier = Modifier.size(40.dp),
                                        elevation = FloatingActionButtonDefaults.elevation(
                                            defaultElevation = 0.dp,
                                            pressedElevation = 0.dp
                                        )
                                    ) {
                                        Icon(
                                            painter = painterResource(id = R.drawable.downloadsimple2),
                                            contentDescription = "Bulk Download",
                                            tint = Color.White,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    
                                    // Bulk Transfer Button (Blue)
                                    if (viewModel.selectedHost != null) {
                                        FloatingActionButton(
                                            onClick = {
                                                viewModel.downloadAndTransferAll(context, downloader,
                                                    onProgress = { _, _, _ ->
                                                        // Progress tracking
                                                    },
                                                    onComplete = { success, failed ->
                                                        Toast.makeText(context, "Bulk transfer complete: $success success, $failed failed", Toast.LENGTH_LONG).show()
                                                    }
                                                )
                                                Toast.makeText(context, "Starting bulk transfer of ${viewModel.results.size} ROMs...", Toast.LENGTH_LONG).show()
                                            },
                                            containerColor = Color(0xFF4AB5FB),
                                            contentColor = Color.White,
                                            modifier = Modifier.size(40.dp),
                                            elevation = FloatingActionButtonDefaults.elevation(
                                                defaultElevation = 0.dp,
                                                pressedElevation = 0.dp
                                            )
                                        ) {
                                            Icon(
                                                painter = painterResource(id = R.drawable.arrowsleftright),
                                                contentDescription = "Bulk Transfer",
                                                tint = Color.White,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }
                }
            }
        }
        
                        Spacer(modifier = Modifier.height(12.dp))
                    }
                    
                    // ROM List
            LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 20.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(viewModel.results) { rom ->
                            RomResultCard(
                                rom = rom,
                                context = context,
                                viewModel = viewModel,
                                downloader = downloader,
                        onDownload = {
                            downloader.download(context, rom)
                                    Toast.makeText(context, "Downloading ${rom.displayName}...", Toast.LENGTH_SHORT).show()
                                },
                                onTransfer = { 
                                    if (viewModel.selectedHost != null) {
                                        viewModel.downloadAndTransfer(context, downloader, rom) { success, message ->
                                val toastMessage = if (success) {
                                                "✓ ${rom.displayName} transferred successfully!"
                                } else {
                                                "✗ Transfer failed: ${message ?: "Unknown error"}"
                                            }
                                            Toast.makeText(context, toastMessage, Toast.LENGTH_LONG).show()
                                        }
                                    } else {
                                        Toast.makeText(context, "Please connect to a handheld device first", Toast.LENGTH_LONG).show()
                                    }
                                },
                                onUpload = { 
                                    Toast.makeText(context, "Upload functionality coming soon...", Toast.LENGTH_SHORT).show()
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RomResultCard(
    rom: RomItem,
    context: android.content.Context,
    viewModel: MainViewModel,
    downloader: Downloader,
    onDownload: () -> Unit,
    onTransfer: () -> Unit,
    onUpload: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(1.dp, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = rom.displayName,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF111827),
                    fontSize = 16.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                
                Spacer(modifier = Modifier.height(4.dp))
                
                Text(
                    text = rom.platform.label,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF9CA3AF),
                    fontSize = 12.sp
                )
            }
            
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Download Button (Green) - Using DownloadSimple2
                FloatingActionButton(
                    onClick = onDownload,
                    containerColor = Color(0xFF42B846),
                    contentColor = Color.White,
                    modifier = Modifier.size(40.dp),
                    elevation = FloatingActionButtonDefaults.elevation(
                        defaultElevation = 0.dp,
                        pressedElevation = 0.dp
                    )
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.downloadsimple2),
                        contentDescription = "Download",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
                
                // Transfer Button (Blue) - Using ArrowsLeftRight
                FloatingActionButton(
                    onClick = onTransfer,
                    containerColor = Color(0xFF4AB5FB),
                    contentColor = Color.White,
                    modifier = Modifier.size(40.dp),
                    elevation = FloatingActionButtonDefaults.elevation(
                        defaultElevation = 0.dp,
                        pressedElevation = 0.dp
                    )
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.arrowsleftright),
                        contentDescription = "Transfer",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}
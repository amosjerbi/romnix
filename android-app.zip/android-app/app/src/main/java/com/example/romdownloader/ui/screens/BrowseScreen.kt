package com.example.romdownloader.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import android.widget.Toast
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.romdownloader.Downloader
import com.example.romdownloader.MainViewModel
import com.example.romdownloader.Platform
import com.example.romdownloader.PlatformManager
import com.example.romdownloader.RomItem
import com.example.romdownloader.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrowseScreen(
    viewModel: MainViewModel,
    downloader: Downloader
) {
    val context = LocalContext.current
    var selectedPlatform by remember { mutableStateOf(viewModel.selectedPlatform) }
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Header
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(top = 48.dp, bottom = 24.dp, start = 20.dp, end = 20.dp)
            ) {
                Text(
                    text = "Browse ROMs",
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF111827),
                    fontSize = 32.sp
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Text(
                    text = "Select platforms you added",
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF9CA3AF),
                    fontSize = 16.sp
                )
            }
            
            // Search Section
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Search Field
                OutlinedTextField(
                    value = viewModel.searchTerm,
                    onValueChange = { viewModel.updateSearchTerm(it) },
                    modifier = Modifier.weight(1f),
                    placeholder = { 
                        Text(
                            "Search ROMs...",
                            color = Color(0xFF9CA3AF),
                            fontWeight = FontWeight.Medium
                        ) 
                    },
                    trailingIcon = if (viewModel.searchTerm.isNotEmpty()) {
                        {
                            IconButton(onClick = { 
                                viewModel.updateSearchTerm("")
                                viewModel.clearResults()
                            }) {
                                Icon(
                                    Icons.Default.Close,
                                    contentDescription = "Clear",
                                    tint = Color(0xFF6B7280),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    } else null,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF2F325A),
                        unfocusedBorderColor = Color(0xFFE5E7EB),
                        cursorColor = Color(0xFF2F325A),
                        focusedTextColor = Color(0xFF111827),
                        unfocusedTextColor = Color(0xFF111827)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )
                    
                // Search Button (Circular)
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .background(
                            color = Color(0xFF2F325A),
                            shape = androidx.compose.foundation.shape.CircleShape
                        )
                        .clickable {
                            if (!viewModel.isSearching) {
                                if (selectedPlatform != null) {
                                    viewModel.searchSelected()
                                } else {
                                    viewModel.searchAll()
                                }
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    if (viewModel.isSearching) {
                        CircularProgressIndicator(
                            color = Color.White,
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(24.dp)
                        )
                    } else {
                        Icon(
                            painter = painterResource(id = R.drawable.search_nav),
                            contentDescription = "Search",
                            modifier = Modifier.size(24.dp),
                            tint = Color.White
                        )
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Platform Filter Chips
            if (selectedPlatform != null || viewModel.searchTerm.isNotEmpty()) {
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Show search term chip if there's a search term
                    if (viewModel.searchTerm.isNotEmpty()) {
                        item {
                            FilterChip(
                                selected = true,
                                onClick = {
                                    viewModel.updateSearchTerm("")
                                    viewModel.clearResults()
                                },
                                label = { 
                                    Text(
                                        viewModel.searchTerm,
                                        fontWeight = FontWeight.Medium,
                                        color = Color(0xFF111827)
                                    ) 
                                },
                                trailingIcon = {
                                    Icon(
                                        Icons.Default.Close,
                                        contentDescription = "Clear search",
                                        modifier = Modifier.size(16.dp),
                                        tint = Color(0xFF6B7280)
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFFF3F4F6),
                                    selectedLabelColor = Color(0xFF111827)
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = true,
                                    borderColor = Color(0xFFE5E7EB),
                                    selectedBorderColor = Color(0xFFE5E7EB)
                                )
                            )
                        }
                    }
                    
                    // Show platform chip if there's a selected platform
                    if (selectedPlatform != null) {
                        item {
                            FilterChip(
                                selected = true,
                                onClick = {
                                    selectedPlatform = null
                                    viewModel.setPlatform(null)
                                    viewModel.clearResults()
                                },
                                label = { 
                                    Text(
                                        selectedPlatform!!.label,
                                        fontWeight = FontWeight.Medium,
                                        color = Color(0xFF111827)
                                    ) 
                                },
                                trailingIcon = {
                                    Icon(
                                        Icons.Default.Close,
                                        contentDescription = "Clear platform",
                                        modifier = Modifier.size(16.dp),
                                        tint = Color(0xFF6B7280)
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFFF3F4F6),
                                    selectedLabelColor = Color(0xFF111827)
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = true,
                                    borderColor = Color(0xFFE5E7EB),
                                    selectedBorderColor = Color(0xFFE5E7EB)
                                )
                            )
                        }
                    }
                    
                    // Clear all button
                    if (selectedPlatform != null || viewModel.searchTerm.isNotEmpty()) {
                        item {
                            FilterChip(
                                selected = false,
                                onClick = {
                                    selectedPlatform = null
                                    viewModel.setPlatform(null)
                                    viewModel.updateSearchTerm("")
                                    viewModel.clearResults()
                                },
                                label = { 
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            Icons.Default.Close,
                                            contentDescription = null,
                                            modifier = Modifier.size(14.dp),
                                            tint = Color(0xFF6B7280)
                                        )
                                        Text(
                                            "Clear",
                                            fontWeight = FontWeight.Medium,
                                            color = Color(0xFF6B7280)
                                        )
                                    }
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    containerColor = Color.White,
                                    labelColor = Color(0xFF6B7280)
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = false,
                                    borderColor = Color(0xFFE5E7EB)
                                )
                            )
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
            }
            
            // ROM Results
            if (viewModel.results.isEmpty() && !viewModel.isSearching) {
                // No Results
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No ROMs found",
                        style = MaterialTheme.typography.bodyLarge,
                        color = Color(0xFF9CA3AF)
                    )
                }
            } else if (viewModel.results.isNotEmpty()) {
                Column {
                    // Bulk Download Card (when multiple results)
                    if (viewModel.results.size > 1) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                                .padding(horizontal = 20.dp)
                                .border(1.dp, Color(0xFFE5E7EB), RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(
                                containerColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                        text = "Bulk Download",
                                        style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Bold,
                                        color = Color(0xFF111827),
                                        fontSize = 16.sp
                            )
                                    
                                    Spacer(modifier = Modifier.height(4.dp))
                                    
                            Text(
                                        text = "${viewModel.results.size} ROMs found",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Medium,
                                        color = Color(0xFF9CA3AF),
                                        fontSize = 12.sp
                                    )
                                }
                                
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    // Bulk Download Button (Transparent)
                                    IconButton(
                                        onClick = {
                                            viewModel.results.forEach { rom ->
                                                downloader.download(context, rom)
                                            }
                                            Toast.makeText(context, "Downloading ${viewModel.results.size} ROMs...", Toast.LENGTH_LONG).show()
                                        },
                                        modifier = Modifier.size(44.dp)
                                    ) {
                                        Icon(
                                            painter = painterResource(id = R.drawable.downloadsimple_new),
                                            contentDescription = "Bulk Download",
                                            tint = Color(0xFF6B7280),
                                            modifier = Modifier.size(24.dp)
                                        )
                                    }
                                    
                                    // Bulk Transfer Button (Blue Circle)
                                    if (viewModel.selectedHost != null) {
                                        Box(
                                            modifier = Modifier
                                                .size(44.dp)
                                                .background(
                                                    color = Color(0xFF2F325A),
                                                    shape = androidx.compose.foundation.shape.CircleShape
                                                )
                                                .clickable {
                                                    viewModel.downloadAndTransferAll(context, downloader,
                                                        onProgress = { _, _, _ ->
                                                            // Progress tracking
                                                        },
                                                        onComplete = { success, failed ->
                                                            Toast.makeText(context, "Bulk transfer complete: $success success, $failed failed", Toast.LENGTH_LONG).show()
                                                        }
                                                    )
                                                    Toast.makeText(context, "Starting bulk transfer of ${viewModel.results.size} ROMs...", Toast.LENGTH_LONG).show()
                                                },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                painter = painterResource(id = R.drawable.arrowsleftright),
                                                contentDescription = "Bulk Transfer",
                                                tint = Color.White,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }
                }
            }
        }
        
                        Spacer(modifier = Modifier.height(12.dp))
                    }
                    
                    // ROM List
            LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 20.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(viewModel.results) { rom ->
                            RomResultCard(
                                rom = rom,
                                context = context,
                                viewModel = viewModel,
                                downloader = downloader,
                        onDownload = {
                            downloader.download(context, rom)
                                    Toast.makeText(context, "Downloading ${rom.displayName}...", Toast.LENGTH_SHORT).show()
                                },
                                onTransfer = { 
                                    if (viewModel.selectedHost != null) {
                                        viewModel.downloadAndTransfer(context, downloader, rom) { success, message ->
                                val toastMessage = if (success) {
                                                "✓ ${rom.displayName} transferred successfully!"
                                } else {
                                                "✗ Transfer failed: ${message ?: "Unknown error"}"
                                            }
                                            Toast.makeText(context, toastMessage, Toast.LENGTH_LONG).show()
                                        }
                                    } else {
                                        Toast.makeText(context, "Please connect to a handheld device first", Toast.LENGTH_LONG).show()
                                    }
                                },
                                onUpload = { 
                                    Toast.makeText(context, "Upload functionality coming soon...", Toast.LENGTH_SHORT).show()
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RomResultCard(
    rom: RomItem,
    context: android.content.Context,
    viewModel: MainViewModel,
    downloader: Downloader,
    onDownload: () -> Unit,
    onTransfer: () -> Unit,
    onUpload: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFFE5E7EB), RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        ),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 0.dp
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = rom.displayName,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF111827),
                    fontSize = 16.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                
                Spacer(modifier = Modifier.height(6.dp))
                
                Text(
                    text = rom.platform.label,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF9CA3AF),
                    fontSize = 14.sp
                )
            }
            
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Download Button (Transparent)
                IconButton(
                    onClick = onDownload,
                    modifier = Modifier.size(44.dp)
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.downloadsimple_new),
                        contentDescription = "Download",
                        tint = Color(0xFF6B7280),
                        modifier = Modifier.size(24.dp)
                    )
                }
                
                // Transfer Button (Red Circle)
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .background(
                            color = Color(0xFFF32C2C),
                            shape = androidx.compose.foundation.shape.CircleShape
                        )
                        .clickable { onTransfer() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.arrowsleftright),
                        contentDescription = "Transfer",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

package com.example.romdownloader.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.window.Dialog
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.romdownloader.Platform
import com.example.romdownloader.PlatformManager
import com.example.romdownloader.MainViewModel
import com.example.romdownloader.R

data class ConsoleItem(
    val platform: Platform,
    val icon: ImageVector = Icons.Default.Games
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConsoleSelectScreen(
    viewModel: MainViewModel,
    onConsoleSelected: (Platform) -> Unit
) {
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }
    var showAddDialog by remember { mutableStateOf(false) }
    var refreshTrigger by remember { mutableStateOf(0) }
    
    // Force recomposition when platforms change
    LaunchedEffect(refreshTrigger) {
        PlatformManager.loadCustomPlatforms(context)
    }
    
    val consoles = PlatformManager.all.map { platform ->
        val icon = when (platform.id) {
            "nes", "snes", "genesis" -> Icons.Default.SportsEsports
            "gb", "gba", "gbc", "gamegear", "ngp" -> Icons.Default.Gamepad
            "n64", "ps1", "dreamcast", "saturn", "tg16" -> Icons.Default.VideogameAsset
            "segacd", "sega32x" -> Icons.Default.Album
            else -> Icons.Default.Games
        }
        ConsoleItem(platform, icon)
    }
    
    val filteredConsoles = if (searchQuery.isEmpty()) {
        consoles
    } else {
        consoles.filter { 
            it.platform.label.contains(searchQuery, ignoreCase = true) 
        }
    }
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Header (no gradient, clean white)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(top = 48.dp, bottom = 24.dp, start = 20.dp, end = 20.dp)
            ) {
                Text(
                    text = "Search Console",
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF111827),
                    fontSize = 32.sp
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Text(
                    text = "Select platforms you added",
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF9CA3AF),
                    fontSize = 16.sp
                )
            }
            
            // Search Bar (matching design exactly)
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                placeholder = { 
                    Text(
                        "Consoles",
                        color = Color(0xFF9CA3AF),
                        fontWeight = FontWeight.Medium,
                        fontSize = 16.sp
                    ) 
                },
                leadingIcon = {
                    Icon(
                        painter = painterResource(id = R.drawable.search_nav),
                        contentDescription = "Search",
                        tint = Color(0xFF6B7280),
                        modifier = Modifier.size(20.dp)
                    )
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF2F325A),
                    unfocusedBorderColor = Color(0xFFE5E7EB),
                    cursorColor = Color(0xFF2F325A),
                    focusedTextColor = Color(0xFF2F325A),
                    unfocusedTextColor = Color(0xFF2F325A)
                ),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )
            
            // Content Area
            if (PlatformManager.all.isEmpty() || filteredConsoles.isEmpty()) {
                // Empty State
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 24.dp, vertical = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    // ROM NIX Logo (light)
                    Icon(
                        painter = painterResource(id = R.drawable.romnix_emptystate),
                        contentDescription = "ROM NIX Logo",
                        modifier = Modifier.size(140.dp),
                        tint = Color.Unspecified
                    )
                    
                    Spacer(modifier = Modifier.height(24.dp))
                    
                    Text(
                        text = "NO CONSOLE FOUND",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF111827),
                        fontSize = 20.sp,
                        letterSpacing = 0.5.sp
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Text(
                        text = "Add custom platform in home",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF9CA3AF),
                        textAlign = TextAlign.Center,
                        fontSize = 14.sp,
                        lineHeight = 20.sp
                    )
                    
                    Spacer(modifier = Modifier.height(32.dp))
                    
                    // Red FAB (no shadow)
                    FloatingActionButton(
                        onClick = { showAddDialog = true },
                        containerColor = Color(0xFFEF4444),
                        contentColor = Color.White,
                        modifier = Modifier.size(56.dp),
                        shape = CircleShape,
                        elevation = FloatingActionButtonDefaults.elevation(
                            defaultElevation = 0.dp,
                            pressedElevation = 0.dp,
                            focusedElevation = 0.dp,
                            hoveredElevation = 0.dp
                        )
                    ) {
                        Icon(
                            Icons.Default.Add,
                            contentDescription = "Add Platform",
                            modifier = Modifier.size(24.dp),
                            tint = Color.White
                        )
                    }
                }
            } else {
                // Console Grid (when platforms exist) - Clean card design
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 20.dp, vertical = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filteredConsoles) { console ->
                        CleanConsoleCard(
                            console = console,
                            onClick = { onConsoleSelected(console.platform) }
                        )
                    }
                }
            }
        }
    }
    
    // Add Platform Dialog
    if (showAddDialog) {
        AddPlatformDialog(
            onDismiss = { showAddDialog = false },
            onSave = { platform ->
                PlatformManager.addCustomPlatform(context, platform)
                showAddDialog = false
                refreshTrigger++
            }
        )
    }
}

@Composable
fun CleanConsoleCard(
    console: ConsoleItem,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .border(1.dp, Color(0xFFE5E7EB), RoundedCornerShape(12.dp)),
        onClick = onClick,
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Platform icon using Search_platform image
            Icon(
                painter = painterResource(id = R.drawable.search_platform),
                contentDescription = console.platform.label,
                modifier = Modifier.size(48.dp),
                tint = Color.Unspecified
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            Text(
                text = console.platform.label,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                color = Color(0xFF111827),
                fontSize = 12.sp
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddPlatformDialog(
    onDismiss: () -> Unit,
    onSave: (Platform) -> Unit
) {
    var platformName by remember { mutableStateOf("") }
    var archiveUrl by remember { mutableStateOf("") }
    var extensions by remember { mutableStateOf("gbc, 7z") }
    
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(
                modifier = Modifier.padding(24.dp)
            ) {
                Text(
                    text = "ADD A PLATFORM",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF111827),
                    fontSize = 18.sp
                )
                
                Spacer(modifier = Modifier.height(24.dp))
                
                OutlinedTextField(
                    value = platformName,
                    onValueChange = { platformName = it },
                    placeholder = { Text("Platform name") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                OutlinedTextField(
                    value = archiveUrl,
                    onValueChange = { archiveUrl = it },
                    placeholder = { Text("Archive URL") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                OutlinedTextField(
                    value = extensions,
                    onValueChange = { extensions = it },
                    placeholder = { Text("File extensions") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                )
                
                Spacer(modifier = Modifier.height(24.dp))
                
                Button(
                    onClick = {
                        if (platformName.isNotBlank() && archiveUrl.isNotBlank()) {
                            val extensionsList = extensions.split(",").map { it.trim() }
                            onSave(
                                Platform(
                                    id = platformName.lowercase().replace(" ", ""),
                                    label = platformName,
                                    archiveUrl = archiveUrl,
                                    extensions = extensionsList,
                                    isCustom = true
                                )
                            )
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444))
                ) {
                    Text("SAVE", color = Color.White, fontWeight = FontWeight.Bold)
                }
                
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("CANCEL", color = Color(0xFF6B7280), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
